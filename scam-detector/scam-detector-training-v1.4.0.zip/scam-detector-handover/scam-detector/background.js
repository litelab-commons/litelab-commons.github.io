// background.js
var lastScores = {}; // tabId -> {url, host, score, hits}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg.type === 'SCORE_UPDATE') {
    var tabId = sender.tab && sender.tab.id;
    if (tabId !== undefined) {
      var existing = lastScores[tabId];
      // all_frames:true のため複数フレーム(隠しiframe等)から届く。
      // 危険なフレームのスコアがdecoyフレームの低スコアで上書きされないよう、
      // タブ単位で最大値を保持する。
      if (!existing || msg.score >= existing.score) {
        lastScores[tabId] = {
          url: msg.url,
          host: msg.host,
          score: msg.score,
          hits: msg.hits,
          updatedAt: Date.now()
        };
      }
      updateBadge(tabId, lastScores[tabId].score);
    }
    return false;
  }

  if (msg.type === 'CLOSE_TAB') {
    var closeTabId = sender.tab && sender.tab.id;
    if (closeTabId !== undefined) {
      chrome.tabs.remove(closeTabId);
    }
    return false;
  }

  if (msg.type === 'FORCE_CLOSE_TAB') {
    // ポップアップ(別プロセス)から直接呼ばれるため、対象ページのJSが
    // setInterval等で混雑/フリーズしていても確実にタブを閉じられる
    if (typeof msg.tabId === 'number') {
      chrome.tabs.remove(msg.tabId);
    }
    return false;
  }

  if (msg.type === 'GET_LAST_SCORE') {
    sendResponse(lastScores[msg.tabId] || null);
    return false;
  }
});

chrome.tabs.onRemoved.addListener(function (tabId) {
  delete lastScores[tabId];
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo) {
  // 同タブで新しいページに遷移した場合、前のページの最高スコアを引き継がないようにする
  if (changeInfo.status === 'loading' && changeInfo.url) {
    delete lastScores[tabId];
    chrome.action.setBadgeText({ tabId: tabId, text: '' });
  }
});

function updateBadge(tabId, score) {
  var text = '';
  var color = '#999999';

  if (score >= 50) {
    text = '!';
    color = '#c0392b';
  } else if (score >= 25) {
    text = '?';
    color = '#e67e22';
  }

  chrome.action.setBadgeText({ tabId: tabId, text: text });
  chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: color });
}
