// content.js
(function () {
  'use strict';

  if (window.__scamDetectorInjected) {
    return;
  }
  window.__scamDetectorInjected = true;

  var R = SCAM_RULES;
  var checksRun = 0;
  var MAX_CHECKS = 6;
  var CHECK_INTERVAL_MS = 1500;
  var beforeUnloadTrapDetected = false;
  var flaggedAsScam = false;

  // beforeunloadダイアログ濫用(離脱妨害)の検出。
  // ページ側がreturnValueをセットしたりpreventDefaultした場合にフラグを立てる。
  window.addEventListener('beforeunload', function (e) {
    if (e.returnValue || e.defaultPrevented) {
      beforeUnloadTrapDetected = true;
    }
  }, true);

  function getVisibleText() {
    if (!document.body) return '';
    return document.body.innerText.slice(0, 20000);
  }

  function scoreWindow(chunk) {
    var lower = chunk.toLowerCase();
    var score = 0;
    var hits = [];

    R.brandKeywords.forEach(function (k) {
      if (lower.indexOf(k.toLowerCase()) !== -1) {
        score += 15;
        hits.push('brand:' + k);
      }
    });

    R.urgencyKeywords.forEach(function (k) {
      if (chunk.indexOf(k) !== -1) {
        score += 8;
        hits.push('urgency:' + k);
      }
    });

    R.threatKeywords.forEach(function (k) {
      if (chunk.indexOf(k) !== -1) {
        score += 12;
        hits.push('threat:' + k);
      }
    });

    var phoneMatches = chunk.match(R.phoneRegex);
    if (phoneMatches && phoneMatches.length > 0) {
      score += Math.min(phoneMatches.length * 8, 24);
      hits.push('phone_numbers:' + phoneMatches.length);
    }

    if (R.errorCodeRegex.test(chunk)) {
      score += 10;
      hits.push('fake_error_code');
    }

    return { score: score, hits: hits };
  }

  // ページ全体を一括スキャンすると、検索結果ページのように無関係な箇所に
  // ブランド名/脅迫文言/詐欺関連の単語が散らばっているだけで誤検知してしまう。
  // 実際の詐欺警告は数百文字程度の一塊にこれらが密集して現れるため、
  // スライディングウィンドウで「最も密度が高い箇所」のスコアを採用する。
  function scoreContent(text) {
    var windowSize = 700;
    var step = 350;

    if (text.length <= windowSize) {
      return scoreWindow(text);
    }

    var bestScore = 0;
    var bestHits = [];

    for (var i = 0; i < text.length; i += step) {
      var chunk = text.slice(i, i + windowSize);
      var r = scoreWindow(chunk);
      if (r.score > bestScore) {
        bestScore = r.score;
        bestHits = r.hits;
      }
      if (i + windowSize >= text.length) break;
    }

    return { score: bestScore, hits: bestHits };
  }

  function scoreDomain() {
    var host = location.hostname;
    var score = 0;
    var hits = [];

    var isGenericHost = R.genericPaasHosts.some(function (d) {
      return host === d || host.indexOf('.' + d) !== -1 || host.indexOf(d) !== -1;
    });

    var isOfficialBrandDomain = R.officialBrandDomains.some(function (d) {
      return host === d || host.endsWith('.' + d);
    });

    if (isGenericHost && !isOfficialBrandDomain) {
      score += 10;
      hits.push('generic_paas_host:' + host);
    }

    return { score: score, hits: hits };
  }

  function scoreBehavior() {
    var score = 0;
    var hits = [];

    if (beforeUnloadTrapDetected) {
      score += 12;
      hits.push('beforeunload_trap');
    }

    // fullscreen強制の検出(全画面オーバーレイで画面をロックしようとする典型パターン)
    if (document.fullscreenElement) {
      score += 6;
      hits.push('fullscreen_lock');
    }

    return { score: score, hits: hits };
  }

  // Cookie同意バナー等の無害なdecoyページの裏で、フルビューポートの
  // 固定位置iframe(極端に高いz-index)を使って詐欺コンテンツを隠すパターンの検出。
  // all_frames:trueでiframe自体も個別にスキャンするのが主対策だが、構造面からも検出しておく。
  function scoreStructure() {
    var score = 0;
    var hits = [];

    var iframes = document.querySelectorAll('iframe');
    iframes.forEach(function (frame) {
      var style;
      try {
        style = window.getComputedStyle(frame);
      } catch (e) {
        return;
      }
      var rect = frame.getBoundingClientRect();
      var isFullViewport =
        rect.width >= window.innerWidth * 0.9 &&
        rect.height >= window.innerHeight * 0.9;
      var isFixedOrAbsolute = style.position === 'fixed' || style.position === 'absolute';
      var zIndexNum = parseInt(style.zIndex, 10);
      var isExtremeZIndex = !isNaN(zIndexNum) && zIndexNum >= 999999;

      if (isFullViewport && isFixedOrAbsolute && isExtremeZIndex) {
        score += 10;
        hits.push('fullscreen_overlay_iframe');
      }
    });

    var scripts = document.querySelectorAll('script:not([src])');
    scripts.forEach(function (s) {
      var content = s.textContent || '';
      if (content.length > 500 && content.indexOf('atob(') !== -1 && content.indexOf('eval') !== -1) {
        score += 6;
        hits.push('obfuscated_eval_loader');
      }
    });

    return { score: score, hits: hits };
  }

  function isTrustedSearchEngine() {
    var host = location.hostname;
    return R.trustedSearchEngines.some(function (d) {
      return host === d || host.endsWith('.' + d);
    });
  }

  function runCheck() {
    var onSearchEngine = isTrustedSearchEngine();
    var text = getVisibleText();
    var c = onSearchEngine ? { score: 0, hits: [] } : scoreContent(text);
    var d = scoreDomain();
    var b = scoreBehavior();
    var st = scoreStructure();
    var total = c.score + d.score + b.score + st.score;
    var hits = c.hits.concat(d.hits, b.hits, st.hits);

    chrome.runtime.sendMessage({
      type: 'SCORE_UPDATE',
      url: location.href,
      host: location.hostname,
      score: total,
      hits: hits
    });

    if (total >= R.threshold) {
      maybeShowOverlay(total, hits);
    }
  }

  function maybeShowOverlay(score, hits) {
    if (document.getElementById('__scam_detector_overlay__')) return;

    flaggedAsScam = true;

    // beforeunload無効化 + 今後のrequestFullscreen()ブロックをMAIN worldに指示
    try {
      window.postMessage({ type: '__SCAM_DETECTOR_NEUTRALIZE__' }, '*');
    } catch (e) {
      /* ignore */
    }

    exitFullscreenIfNeeded();
    forceCursorVisible();

    chrome.storage.local.get(['whitelist'], function (res) {
      var whitelist = res.whitelist || [];
      if (whitelist.indexOf(location.hostname) !== -1) return;
      renderOverlay(score, hits);
    });
  }

  function exitFullscreenIfNeeded() {
    if (!flaggedAsScam) return; // 通常サイトの正当なフルスクリーン利用は妨げない
    try {
      if (document.fullscreenElement || document.webkitFullscreenElement) {
        (document.exitFullscreen || document.webkitExitFullscreen).call(document);
      }
    } catch (e) {
      /* ignore */
    }
  }

  // cursor:none 等でカーソルを非表示にし、フルスクリーンと組み合わせて
  // 「画面が固まった/操作できない」と錯覚させる手口への対策。
  // !important付きの強いCSSでカーソル表示を強制的に復元する。
  function forceCursorVisible() {
    if (document.getElementById('__scam_detector_cursor_fix__')) return;
    var style = document.createElement('style');
    style.id = '__scam_detector_cursor_fix__';
    style.textContent =
      'html, body, * { cursor: auto !important; } ' +
      '#__scam_detector_overlay__, #__scam_detector_overlay__ * { cursor: default !important; } ' +
      '#__scam_detector_overlay__ button { cursor: pointer !important; }';
    (document.head || document.documentElement).appendChild(style);
  }

  // ページが再度フルスクリーンに入ろうとする/cursor:noneを再適用してくる
  // ケースに備え、継続的に監視して解除する。
  document.addEventListener('fullscreenchange', exitFullscreenIfNeeded);
  document.addEventListener('webkitfullscreenchange', exitFullscreenIfNeeded);

  function renderOverlay(score, hits) {
    var overlay = document.createElement('div');
    overlay.id = '__scam_detector_overlay__';
    overlay.style.cssText =
      'position:fixed;top:0;left:0;width:100%;height:100%;' +
      'background:rgba(10,10,20,0.96);z-index:2147483647;' +
      'display:flex;align-items:center;justify-content:center;' +
      'font-family:-apple-system,"Hiragino Sans","Yu Gothic",sans-serif;';

    var box = document.createElement('div');
    box.style.cssText =
      'max-width:480px;width:90%;background:#fff;border-radius:14px;' +
      'padding:32px;box-shadow:0 10px 40px rgba(0,0,0,0.5);text-align:center;';

    var hitsShown = hits.slice(0, 6).join(' / ');

    box.innerHTML =
      '<div style="font-size:48px;line-height:1;">\u26A0\uFE0F</div>' +
      '<h2 style="color:#c0392b;margin:14px 0 8px;font-size:20px;">' +
        'このページは詐欺サイトの可能性があります' +
      '</h2>' +
      '<p style="color:#333;font-size:14px;line-height:1.7;text-align:left;">' +
        '偽のセキュリティ警告・サポート詐欺によく見られる特徴が検出されました(検出スコア: ' + score + ')。' +
        '<br><br>' +
        '<b>表示されている電話番号には絶対に連絡しないでください。</b>' +
        '<br>' +
        'Microsoft・Apple・各種セキュリティソフトの本物の警告は、ブラウザ上にこのような形式で表示されることはなく、サポートへの電話を強要することもありません。' +
      '</p>' +
      '<div style="margin-top:22px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">' +
        '<button id="__scam_close_tab__" style="background:#c0392b;color:#fff;border:none;' +
          'padding:11px 18px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:bold;">' +
          'このタブを閉じる' +
        '</button>' +
        '<button id="__scam_dismiss__" style="background:#eee;color:#333;border:none;' +
          'padding:11px 18px;border-radius:8px;cursor:pointer;font-size:14px;">' +
          '無視して閲覧を続ける' +
        '</button>' +
      '</div>' +
      '<p style="margin-top:16px;font-size:11px;color:#999;">検出理由: ' + hitsShown + '</p>';

    overlay.appendChild(box);
    document.documentElement.appendChild(overlay);

    document.getElementById('__scam_close_tab__').onclick = function () {
      var btn = document.getElementById('__scam_close_tab__');
      btn.disabled = true;
      btn.textContent = '閉じています...';

      try {
        window.postMessage({ type: '__SCAM_DETECTOR_NEUTRALIZE__' }, '*');
      } catch (e) {
        /* ignore */
      }

      function requestClose() {
        try {
          chrome.runtime.sendMessage({ type: 'CLOSE_TAB' });
        } catch (e) {
          /* extension context invalidated 等。ポップアップから強制終了を案内する */
        }
      }

      requestClose();
      // ページ側の重い setInterval 等で初回が処理待ちになるケースに備え、
      // 念のため少し間を置いて再送する
      setTimeout(requestClose, 400);

      setTimeout(function () {
        if (document.getElementById('__scam_detector_overlay__')) {
          btn.disabled = false;
          btn.textContent = 'このタブを閉じる(拡張機能アイコン→強制終了も使えます)';
        }
      }, 2500);
    };
    document.getElementById('__scam_dismiss__').onclick = function () {
      overlay.parentNode.removeChild(overlay);
    };
  }

  // 初回チェック + 動的に文言が描画されるケースに対応するため数回リトライ
  var intervalId = setInterval(function () {
    runCheck();
    checksRun++;
    if (checksRun >= MAX_CHECKS) {
      clearInterval(intervalId);
    }
  }, CHECK_INTERVAL_MS);

  runCheck();
})();
