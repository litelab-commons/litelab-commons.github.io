// popup.js
var currentTab = null;

function render(scoreData) {
  var box = document.getElementById('statusBox');
  var scoreText = document.getElementById('scoreText');
  var labelText = document.getElementById('labelText');
  var hitsText = document.getElementById('hitsText');
  var forceCloseBtn = document.getElementById('forceCloseBtn');

  if (!scoreData) {
    scoreText.textContent = '--';
    labelText.textContent = 'このページではまだ判定が行われていません(対象外のページかもしれません)';
    box.className = 'status-box status-safe';
    forceCloseBtn.style.display = 'none';
    return;
  }

  scoreText.textContent = scoreData.score;

  if (scoreData.score >= 50) {
    box.className = 'status-box status-danger';
    labelText.textContent = '危険: 詐欺サイトの可能性が高いです';
    forceCloseBtn.style.display = 'block';
  } else if (scoreData.score >= 25) {
    box.className = 'status-box status-warn';
    labelText.textContent = '注意: いくつかの疑わしい特徴があります';
    forceCloseBtn.style.display = 'none';
  } else {
    box.className = 'status-box status-safe';
    labelText.textContent = '現時点で明確な異常は検出されていません';
    forceCloseBtn.style.display = 'none';
  }

  if (scoreData.hits && scoreData.hits.length > 0) {
    hitsText.textContent = '検出内容: ' + scoreData.hits.slice(0, 8).join(' / ');
  } else {
    hitsText.textContent = '';
  }
}

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  if (!tabs || !tabs[0]) return;
  currentTab = tabs[0];

  chrome.runtime.sendMessage({ type: 'GET_LAST_SCORE', tabId: currentTab.id }, function (res) {
    render(res);
  });
});

document.getElementById('forceCloseBtn').addEventListener('click', function () {
  if (!currentTab) return;
  chrome.runtime.sendMessage({ type: 'FORCE_CLOSE_TAB', tabId: currentTab.id });
});

document.getElementById('whitelistBtn').addEventListener('click', function () {
  if (!currentTab || !currentTab.url) return;
  var host = '';
  try {
    host = new URL(currentTab.url).hostname;
  } catch (e) {
    return;
  }

  chrome.storage.local.get(['whitelist'], function (res) {
    var whitelist = res.whitelist || [];
    if (whitelist.indexOf(host) === -1) {
      whitelist.push(host);
    }
    chrome.storage.local.set({ whitelist: whitelist }, function () {
      document.getElementById('labelText').textContent =
        host + ' をホワイトリストに追加しました';
    });
  });
});
