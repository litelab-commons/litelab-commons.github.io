// rules.js
// 判定ルール定義。判定補助ツールと同様の三層スコアリング方式。
// layer1: コンテンツ(テキスト)ヒューリスティック
// layer2: ドメイン/URLヒューリスティック
// layer3: 外部API連携(将来拡張・background.js内でスタブ実装)

var SCAM_RULES = {
  threshold: 50,

  brandKeywords: [
    'windows defender', 'windows security', 'windows_defender',
    'microsoft support', 'microsoftサポート', 'windowsサポート',
    'windowsセキュリティ', 'マイクロソフト', 'apple support',
    'appleサポート', 'norton', 'mcafee', 'セキュリティセンター', 'trend micro'
  ],

  urgencyKeywords: [
    '直ちに', '今すぐ', 'すぐに', 'immediately', 'call now',
    'do not close', 'このウィンドウを閉じる', '再起動したり',
    '閉じないでください', '操作しないでください', 'できるだけ早く',
    '電源を切らないでください', '電源を切らない', '再起動してください',
    'ご連絡ください', '連絡してください', 'お電話ください'
  ],

  threatKeywords: [
    'ウイルスが検出', '個人情報が盗まれ', 'アドウェア',
    'identity theft', 'infected', '盗まれました',
    '銀行のログイン', 'クレジットカード', 'アクセスが制限',
    '無効化されました', 'アクセスをブロック',
    'ウイルスに感染', 'ウイルス感染', '感染を検出',
    'クラッシュしました', 'システムが破損', '破損しました',
    'ファイルを削除', 'コンピュータを保護するため', 'データが破損'
  ],

  phoneRegex: /(0\d{1,4}[-\s]?\d{2,4}[-\s]?\d{3,4}[-\s]?\d{3,4}|\+?\d{1,3}[-\s]\d{2,4}[-\s]\d{3,4}[-\s]\d{3,4})/g,

  errorCodeRegex: /エラーコード[:\s]*[A-Za-z0-9]{4,}/,

  genericPaasHosts: [
    'amplifyapp.com', 'herokuapp.com', 'vercel.app', 'netlify.app',
    'firebaseapp.com', 'web.app', 'glitch.me', '000webhostapp.com',
    'weebly.com', 'wixsite.com', 'github.io', 'pages.dev', 'azurewebsites.net'
  ],

  officialBrandDomains: [
    'microsoft.com', 'live.com', 'apple.com', 'google.com', 'norton.com', 'mcafee.com'
  ],

  // 検索エンジンのSERP自体が詐欺ページ本体になることは実質ない。
  // 様々な検索結果スニペットに用語が分散して誤検知するのを防ぐため、
  // これらのドメインではコンテンツ判定(layer1)をスキップする。
  trustedSearchEngines: [
    'google.com', 'google.co.jp', 'bing.com', 'search.yahoo.co.jp', 'yahoo.co.jp',
    'duckduckgo.com', 'baidu.com', 'yandex.com', 'ecosia.org', 'so.com',
    'search.brave.com', 'startpage.com'
  ]
};

if (typeof module !== 'undefined') {
  module.exports = SCAM_RULES;
}
