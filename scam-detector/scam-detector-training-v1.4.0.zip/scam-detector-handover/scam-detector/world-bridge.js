// world-bridge.js
// このスクリプトはページ本体のJS実行コンテキスト(MAIN world)で動作する。
// content.js(isolated world)はページの window.onbeforeunload を直接操作できないため、
// window.postMessage経由でこちらに「無効化」を指示してもらう。
(function () {
  'use strict';

  if (window.__scamBridgeInstalled) return;
  window.__scamBridgeInstalled = true;

  var neutralized = false;
  var realHandler = null;
  var trackedListeners = []; // {target, listener, options}

  // onbeforeunload プロパティ経由の登録を横取り(実体は1本の内部リスナーに統一)
  try {
    Object.defineProperty(window, 'onbeforeunload', {
      configurable: true,
      get: function () {
        return realHandler;
      },
      set: function (fn) {
        realHandler = typeof fn === 'function' ? fn : null;
      }
    });
  } catch (e) {
    // 古い環境などで defineProperty が失敗してもページ動作は壊さない
  }

  // 内部リスナー(実際にbeforeunloadイベントを受け取る唯一の窓口)
  window.addEventListener('beforeunload', function (e) {
    if (neutralized) return;
    if (typeof realHandler === 'function') {
      var result = realHandler(e);
      if (result !== undefined) e.returnValue = result;
    }
  }, true);

  // addEventListener('beforeunload', ...) で登録されたものも記録しておき、
  // 無効化指示が来たら一括解除する
  var originalAdd = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, listener, options) {
    if (type === 'beforeunload' && this === window) {
      trackedListeners.push({ target: this, listener: listener, options: options });
    }
    return originalAdd.call(this, type, listener, options);
  };

  function neutralize() {
    if (neutralized) return;
    neutralized = true;
    realHandler = null;

    trackedListeners.forEach(function (entry) {
      try {
        entry.target.removeEventListener('beforeunload', entry.listener, entry.options);
      } catch (e) {
        /* ignore */
      }
    });

    // ページが多重に setInterval / setTimeout を仕込んでブラウザを混雑させてくる
    // ケースに備え、以降に追加される高頻度タイマーも軽く間引く(既存のものは止めない)
    var originalSetInterval = window.setInterval;
    window.setInterval = function (fn, delay) {
      var safeDelay = (typeof delay === 'number' && delay < 50) ? 50 : delay;
      return originalSetInterval.call(window, fn, safeDelay);
    };

    // requestFullscreen() を使った画面占有(+ cursor:none によるカーソル消去との
    // 組み合わせ)を以降ブロックする。既存の呼び出し結果(現在の全画面状態)は
    // content.js側でexitFullscreen()される。
    var noopFullscreen = function () {
      return Promise.reject(new DOMException('Blocked by scam detector', 'NotAllowedError'));
    };
    [
      'requestFullscreen',
      'webkitRequestFullscreen',
      'webkitRequestFullScreen',
      'mozRequestFullScreen',
      'msRequestFullscreen'
    ].forEach(function (fnName) {
      if (Element.prototype[fnName]) {
        try {
          Element.prototype[fnName] = noopFullscreen;
        } catch (e) {
          /* ignore */
        }
      }
    });

    if (Element.prototype.requestPointerLock) {
      try {
        Element.prototype.requestPointerLock = function () { return undefined; };
      } catch (e) {
        /* ignore */
      }
    }
  }

  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data) return;
    if (e.data.type === '__SCAM_DETECTOR_NEUTRALIZE__') {
      neutralize();
    }
  });
})();
