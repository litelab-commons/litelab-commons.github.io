# HANDOVER.md — 詐欺サイト判定くん (Scam Site Detector)

このドキュメントは、本プロジェクトをClaude Code(または他の開発者/AIエージェント)に
引き継ぐための要約です。詳細はREADME.md(拡張機能の使い方・アーキテクチャ・変更履歴)
と PRIVACY.md(プライバシーポリシー)を参照してください。

## 現状ステータス

- バージョン: **1.4.0**
- ステータス: 配布準備が一通り完了した状態。Chrome Web Store未提出。
- 形式: Chrome/Edge向け Manifest V3 拡張機能(「パッケージ化されていない拡張機能」として
  手動読み込みする前提。ストア未公開)
- 動作確認: 実際のサポート詐欺検体(電話誘導型ブラウザロッカー、Cookie同意decoy+隠しiframe型)
  2種類に対して、Playwright + Xvfbで実機検証済み。

## ディレクトリ構成

```
scam-detector/              拡張機能本体(配布物)
├── manifest.json            Manifest V3定義(content_scripts, permissions等)
├── rules.js                  判定ルール定義(キーワード・正規表現・ドメインリスト)
├── content.js                各フレームで実行される判定ロジック+オーバーレイ表示
├── world-bridge.js           MAIN worldで動作するbeforeunload/fullscreen対策
├── background.js             service worker(バッジ表示・タブ操作)
├── popup.html / popup.js     ツールバーアイコンのポップアップ
├── options.html / options.js ホワイトリスト管理(追加/削除/インポート/エクスポート)
├── icons/                    アイコン(16/32/48/128px、PIL生成の簡易シールドアイコン)
├── README.md                 機能・使い方・アーキテクチャ・CHANGELOG
└── PRIVACY.md                プライバシーポリシー(Chrome Web Store提出用)

docs/
├── scam-detector-manual.docx   インストール・アンインストール手順書(実画面スクショ付き)
└── scam-detector-report.docx   検出ロジック報告書(目的・設計思想・期待される効果)

testing/
├── test-scam-page.html        判定テスト用の安全なページ(実害なし、検出層ごとにON/OFF可能)
└── README.md                   テストページの使い方

HANDOVER.md                   本ファイル
```

## 検出アーキテクチャの要約

4層のヒューリスティックでスコアを合算し、閾値(50点、`rules.js`の`R.threshold`)を
超えると全画面オーバーレイで警告する。詳細は `scam-detector-report.docx` および
README.mdの「判定アーキテクチャ」section参照。

1. **コンテンツ判定**(`content.js: scoreContent`)— ブランド偽装・脅迫文言・電話番号・
   偽エラーコードを、700文字スライディングウィンドウで判定(誤検知抑制のため全文一括スキャンはしない)
2. **ドメイン判定**(`scoreDomain`)— 汎用PaaSサブドメイン上でのブランド偽装
3. **構造判定**(`scoreStructure`)— フルビューポート固定iframe、atob+eval難読化ローダー
4. **挙動判定**(`scoreBehavior`)— beforeunload濫用、フルスクリーン強制

検出後は `world-bridge.js`(MAIN world)経由でbeforeunload/fullscreen/pointerLockを
無効化し、`content.js`がカーソル復元・オーバーレイ表示を行う。

## これまでの開発の経緯(重要な意思決定)

1. **v1.0**: 電話誘導型サポート詐欺の検出+全画面警告で初版作成。
2. **v1.1**: 実検体で「閉じる」を押しても画面が固まる不具合を確認 → 原因は
   beforeunload多重登録+setIntervalスパム(ブラウザロッカー)。MAIN world連携での
   beforeunload無効化と、ポップアップからの強制終了ボタンを追加。
3. **v1.2**: 別の実検体で「検出すらしない」不具合を確認 → Cookie同意ダイアログを
   decoyにした隠しiframe(`about:srcdoc`)の中に実際の詐欺コンテンツがあり、
   `all_frames: false`だったため検出できていなかった。`all_frames: true`化+
   タブ単位の最大スコア保持+構造的ヒューリスティックを追加。
4. **v1.3**: 同検体で画面が最大化・カーソル消失する不具合を確認 →
   `requestFullscreen()`×3 + CSS `cursor:none` が原因。検出時の自動解除と
   以降の再突入ブロックを追加。
5. **v1.4.0**: 検索結果ページ(「マイクロソフト」「サポート詐欺」等で検索)での
   誤検知を確認 → ページ全体一括スキャンが原因。スライディングウィンドウ方式+
   主要検索エンジンのスキップリストで対策。配布向けに外部API連携(layer3)を削除し、
   ホワイトリストのインポート/エクスポートを追加。権限を最小化。

**教訓**: このプロジェクトは「実際の検体を解析 → 不具合/検出漏れを特定 → ルール/
仕組みを修正 → 再検証」のサイクルで進めてきた。新しい検体が手に入った場合は、
まず手動でファイル構造とJS(`beforeunload`, `setInterval`, `requestFullscreen`,
`atob`/`eval`, iframe構造等)を grep して特徴を掴み、Node.jsで`rules.js`の
スコアリングロジックを抜き出してシミュレーションしてから、実装に反映するのが
効率的(本プロジェクトの会話履歴で繰り返し使った手法)。

## テスト・検証の方法

### スコアリングのシミュレーション(実装前の確認に有効)
`rules.js` は `module.exports` 対応済みなので、Node.jsから直接読み込んで
スコアリング関数のロジック部分(content.js内のscoreWindow等)をコピーして
実行すれば、ブラウザを起動せずに数値を確認できる。本プロジェクトでは
誤検知対策やキーワード拡充の妥当性をこの方法で都度検証した。

### 実ブラウザでの動作確認(Playwright + Xvfb)
本サンドボックス環境には Playwright(Python, Chromiumブラウザ込み)と
`xvfb-run` が利用可能。以下の方法で「パッケージ化されていない拡張機能」を
読み込んだ状態のChromiumを起動し、実際の動作(オーバーレイ表示、ポップアップ、
chrome://extensions の操作)をスクリーンショットで確認できる。

```python
from playwright.sync_api import sync_playwright

EXT_PATH = "/path/to/scam-detector"
ctx = p.chromium.launch_persistent_context(
    "/path/to/profile-dir",
    headless=False,  # 拡張機能を使うにはheadless=Falseが必須
    args=[
        f"--disable-extensions-except={EXT_PATH}",
        f"--load-extension={EXT_PATH}",
        "--no-sandbox",
    ],
)
```

`xvfb-run -a python3 script.py` で仮想ディスプレイ上に実行する。長時間かかる
操作は `setsid nohup ... &` で完全にデタッチしたバックグラウンドプロセスとして
起動し、ログファイルをポーリングする方式が安定する(フォアグラウンド実行だと
ツールのタイムアウトで失敗することがあった)。

拡張機能のIDは `ctx.service_workers` の `chrome-extension://<ID>/...` から取得できる。
ポップアップUIを直接検証する場合は `chrome-extension://<ID>/popup.html` を**新しい
タブではなく既存タブの再読み込みで**開かないと、ポップアップタブ自体がアクティブタブに
なってしまい `chrome.tabs.query({active:true})` が誤った対象を返す点に注意
(本プロジェクトで実際に踏んだ落とし穴)。

### file://サンプルの取り扱い
アップロードされたzip化済み検体(ブラウザの「名前を付けて保存」形式)を展開する際、
unzipが日本語ファイル名を `#U306e` のような文字コード表記に変換してしまうことがある。
HTML内の相対パス参照(`./Cookie の設定_files/...`)は実際の日本語文字列を期待しているため、
`shutil.copytree`で正しいファイル名のディレクトリを作り直す必要がある場合がある。

## 未対応・今後の課題(README.mdと同内容)

- 多重ネストされたiframeやShadow DOM内への深い隠蔽など、未検証の回避手口
- 検出ルール(`rules.js`)は実際に確認された2種類の検体をもとにした初期セットであり、
  新たな亜種に応じた継続的な更新が必要
- 判定スコアの永続化なし(タブを閉じると履歴が破棄される)。組織内での検出傾向集計が
  必要であれば `chrome.storage.local` への記録機構を追加検討
- Chrome Web Store未提出(PRIVACY.mdの公開URL確保とストア掲載作業が残っている)

## 環境・依存関係メモ

- ビルドツールなし(vanilla JS、ES5寄りの記法に統一)。npm/webpack等は不要。
- ドキュメント生成(docx)には `npm install -g docx` を使用(本サンドボックスには導入済み)。
- 実ブラウザ検証には Python `playwright`(`playwright install chromium`)と
  `xvfb-run`(`apt`パッケージ`xvfb`)を使用。
- アイコンはPython PIL(Pillow)でシールド形状を描画して生成した簡易版。
  デザインを差し替える場合は `icons/icon{16,32,48,128}.png` を置き換えるだけでよい。

## このzipに含まれるもの

```
scam-detector/                拡張機能本体(README.md, PRIVACY.md含む)
docs/scam-detector-manual.docx   インストール/アンインストール手順書
docs/scam-detector-report.docx   検出ロジック報告書
testing/test-scam-page.html      判定テスト用の安全なページ(実害なし)
HANDOVER.md                    本ファイル
```
