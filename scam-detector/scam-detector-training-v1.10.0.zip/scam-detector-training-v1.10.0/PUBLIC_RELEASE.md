# 公開用メモ

## 公開対象

このZIPには、利用者が研修・検証で使うために必要な最小限のファイルだけを含めます。

- `scam-detector/`: Chrome / Edge 拡張機能本体
- `testing/`: 安全な動作確認用ページ
- `DISCLAIMER.md`: 免責事項
- `PUBLIC_RELEASE.md`: 公開用メモ

## 公開対象外

以下は制作・引き継ぎ・内部確認の資料であり、公開ZIPには含めません。

- `HANDOVER.md`
- `docs/*.docx`
- 作業用フォルダ、検証ログ、未整理の素材

## 注意

本拡張機能は研修・検証用です。Chrome Web Store等で審査された一般向けセキュリティ製品ではありません。配布時は `DISCLAIMER.md` と `scam-detector/PRIVACY.md` を必ず同梱してください。
