// options.js

function loadSettings() {
  chrome.storage.local.get(['whitelist'], function (res) {
    renderWhitelist(res.whitelist || []);
  });
}

function renderWhitelist(list) {
  var ul = document.getElementById('whitelistItems');
  ul.innerHTML = '';

  if (list.length === 0) {
    var empty = document.createElement('li');
    empty.textContent = '(登録なし)';
    empty.style.color = '#999';
    ul.appendChild(empty);
    return;
  }

  list.forEach(function (host) {
    var li = document.createElement('li');

    var span = document.createElement('span');
    span.textContent = host;

    var btn = document.createElement('button');
    btn.textContent = '削除';
    btn.addEventListener('click', function () {
      removeFromWhitelist(host);
    });

    li.appendChild(span);
    li.appendChild(btn);
    ul.appendChild(li);
  });
}

function showStatus(message, isError) {
  var status = document.getElementById('status');
  status.style.color = isError ? '#c0392b' : '#2ecc71';
  status.textContent = message;
  setTimeout(function () {
    status.textContent = '';
  }, 3000);
}

function removeFromWhitelist(host) {
  chrome.storage.local.get(['whitelist'], function (res) {
    var list = (res.whitelist || []).filter(function (h) {
      return h !== host;
    });
    chrome.storage.local.set({ whitelist: list }, function () {
      renderWhitelist(list);
    });
  });
}

document.getElementById('addWhitelistBtn').addEventListener('click', function () {
  var input = document.getElementById('newWhitelistHost');
  var host = input.value.trim();
  if (!host) return;

  chrome.storage.local.get(['whitelist'], function (res) {
    var list = res.whitelist || [];
    if (list.indexOf(host) === -1) {
      list.push(host);
    }
    chrome.storage.local.set({ whitelist: list }, function () {
      input.value = '';
      renderWhitelist(list);
    });
  });
});

// ---- エクスポート ----
document.getElementById('exportBtn').addEventListener('click', function () {
  chrome.storage.local.get(['whitelist'], function (res) {
    var list = res.whitelist || [];
    var payload = {
      type: 'scam-detector-whitelist',
      version: 1,
      exportedAt: new Date().toISOString(),
      hosts: list
    };

    var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    var dateStr = new Date().toISOString().slice(0, 10);

    a.href = url;
    a.download = 'scam-detector-whitelist-' + dateStr + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showStatus('エクスポートしました(' + list.length + '件)', false);
  });
});

// ---- インポート ----
document.getElementById('importBtn').addEventListener('click', function () {
  document.getElementById('importFileInput').click();
});

document.getElementById('importFileInput').addEventListener('change', function (e) {
  var file = e.target.files && e.target.files[0];
  if (!file) return;

  var reader = new FileReader();
  reader.onload = function () {
    var hosts;
    try {
      var parsed = JSON.parse(reader.result);
      if (Array.isArray(parsed)) {
        // 単純な配列形式 ["example.com", ...] もサポート
        hosts = parsed;
      } else if (parsed && Array.isArray(parsed.hosts)) {
        hosts = parsed.hosts;
      } else {
        throw new Error('invalid format');
      }
    } catch (err) {
      showStatus('インポート失敗: JSON形式が正しくありません', true);
      e.target.value = '';
      return;
    }

    hosts = hosts.filter(function (h) {
      return typeof h === 'string' && h.trim().length > 0;
    });

    chrome.storage.local.get(['whitelist'], function (res) {
      var list = res.whitelist || [];
      var added = 0;

      hosts.forEach(function (h) {
        var host = h.trim();
        if (list.indexOf(host) === -1) {
          list.push(host);
          added++;
        }
      });

      chrome.storage.local.set({ whitelist: list }, function () {
        renderWhitelist(list);
        showStatus('インポート完了(' + added + '件追加 / ' + hosts.length + '件中)', false);
        e.target.value = '';
      });
    });
  };

  reader.onerror = function () {
    showStatus('ファイルの読み込みに失敗しました', true);
    e.target.value = '';
  };

  reader.readAsText(file);
});

loadSettings();
