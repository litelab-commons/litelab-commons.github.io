// content.js
(function () {
  'use strict';

  if (window.__scamDetectorInjected) {
    return;
  }
  window.__scamDetectorInjected = true;

  var R = SCAM_RULES;
  var checksRun = 0;
  var MAX_CHECKS = 6;
  var CHECK_INTERVAL_MS = 1500;
  var beforeUnloadTrapDetected = false;
  var flaggedAsScam = false;
  var audioLoopDetected = false;
  var audioLoopCount = 0;
  var fullscreenAttemptDetected = false;
  var pointerLockAttemptDetected = false;
  var keyboardLockAttemptDetected = false;

  // beforeunloadダイアログ濫用(離脱妨害)の検出。
  // ページ側がreturnValueをセットしたりpreventDefaultした場合にフラグを立てる。
  window.addEventListener('beforeunload', function (e) {
    if (e.returnValue || e.defaultPrevented) {
      beforeUnloadTrapDetected = true;
    }
  }, true);

  // world-bridge.js(MAIN world)からの通知を受け取る。
  // (1) 音声無限ループ: DOMに追加されない<audio>要素(document.createElementの
  //     みで生成されappendChildされないもの)はDOM監視では捕捉できないため、
  //     再生API自体の呼び出し回数をMAIN world側で直接数えてもらっている。
  // (2) フルスクリーン試行: 「クリック一発でフルスクリーン化」のような挙動は、
  //     world-bridge.js側でブロックされ実際には全画面化されないため
  //     document.fullscreenElementでは検出できない。試行されたという事実
  //     自体を裏付けシグナルとして受け取る。
  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data) return;
    if (e.data.type === '__SCAM_DETECTOR_AUDIO_LOOP__') {
      audioLoopDetected = true;
      audioLoopCount = e.data.count || audioLoopCount;
    } else if (e.data.type === '__SCAM_DETECTOR_FULLSCREEN_ATTEMPT__') {
      fullscreenAttemptDetected = true;
    } else if (e.data.type === '__SCAM_DETECTOR_POINTER_LOCK_ATTEMPT__') {
      pointerLockAttemptDetected = true;
    } else if (e.data.type === '__SCAM_DETECTOR_KEYBOARD_LOCK_ATTEMPT__') {
      keyboardLockAttemptDetected = true;
    }
  });


  // iframe内で検知した場合、background.jsが最上位フレームへ通知する。
  // これにより、iframeだけでなく親ページ全体を覆う警告を表示できる。
  chrome.runtime.onMessage.addListener(function (msg) {
    if (!msg || msg.type !== 'CHILD_SCAM_DETECTED') return;
    if (window !== window.top) return;
    maybeShowOverlay(msg.score || R.threshold, msg.hits || ['dangerous_child_frame']);
  });

  function getVisibleText() {
    if (!document.body) return '';
    var titleText = document.title || '';
    return (titleText + ' \n ' + document.body.innerText).slice(0, 20000);
  }

  // CSS(display:none/fadeIn等)でまだ見えていない警告文言や、JS文字列リテラルに
  // 直接埋め込まれた電話番号(例: var phone_number = '0120-...';)を、表示状態に
  // 関係なく検出するため、外部読み込みではないインラインscriptタグの中身も
  // スキャン対象に含める。bootstrap/jQuery等の外部ライブラリ(src属性あり)は対象外。
  function getInlineScriptText() {
    var scripts = document.querySelectorAll('script:not([src])');
    var combined = '';
    for (var i = 0; i < scripts.length && combined.length < 8000; i++) {
      combined += ' ' + (scripts[i].textContent || '');
    }
    return combined.slice(0, 8000);
  }

  function scoreWindow(chunk) {
    var lower = chunk.toLowerCase();
    var score = 0;
    var hits = [];
    var categoriesPresent = [];

    Object.keys(R.categories).forEach(function (catKey) {
      var cat = R.categories[catKey];
      var matchedToken = null;
      for (var i = 0; i < cat.tokens.length; i++) {
        var t = cat.tokens[i];
        if (chunk.indexOf(t) !== -1 || lower.indexOf(t.toLowerCase()) !== -1) {
          matchedToken = t;
          break;
        }
      }
      if (matchedToken) {
        score += cat.weight;
        hits.push(catKey + ':' + matchedToken);
        categoriesPresent.push(catKey);
      }
    });

    var phoneMatches = chunk.match(R.phoneRegex);
    if (phoneMatches && phoneMatches.length > 0) {
      score += Math.min(phoneMatches.length * 8, 24);
      hits.push('phone_numbers:' + phoneMatches.length);
      if (categoriesPresent.indexOf('contact') === -1) {
        categoriesPresent.push('contact');
      }
    }

    if (R.errorCodeRegex.test(chunk)) {
      score += 10;
      hits.push('fake_error_code');
    }

    // 「まんべんなく出現」ボーナス: 異なる種類の要素(権威詐称・脅迫・緊急性・
    // 連絡要求)が同じ箇所に何種類同時に揃っているかで加点する。単一カテゴリの
    // 偶然の一致だけでは閾値に届きにくくし、典型的な詐欺ページの構成要素一式が
    // 揃っている場合に重点的に加点することで、個別の言い回しの違いに対する
    // 頑健性を高める。
    // ただし、3カテゴリ以上の高ボーナスは「contact(連絡要求)」を含む場合のみ
    // 適用する。本物の詐欺ページは必ず利用者本人に電話/連絡を直接要求するが、
    // ニュース記事等が三人称で手口を解説するだけの文章(「マイクロソフトを装い
    // ウイルス感染と表示し今すぐ連絡するよう仕向ける詐欺が増えている」等)は
    // 読者本人への行動要求(contact)を伴わないことが多く、この条件で区別できる。
    var hasContact = categoriesPresent.indexOf('contact') !== -1;
    var comboTier = R.comboBonus
      .filter(function (b) {
        if (categoriesPresent.length < b.min) return false;
        if (b.min >= 3 && !hasContact) return false;
        return true;
      })
      .sort(function (a, b) { return b.bonus - a.bonus; })[0];
    if (comboTier) {
      score += comboTier.bonus;
      hits.push('combo_breadth:' + categoriesPresent.length + 'categories(+' + comboTier.bonus + ')');
    }

    return { score: score, hits: hits };
  }

  // ページ全体を一括スキャンすると、検索結果ページのように無関係な箇所に
  // ブランド名/脅迫文言/詐欺関連の単語が散らばっているだけで誤検知してしまう。
  // 実際の詐欺警告は数百文字程度の一塊にこれらが密集して現れるため、
  // スライディングウィンドウで「最も密度が高い箇所」のスコアを採用する。
  function scoreContent(text) {
    var windowSize = 700;
    var step = 350;

    if (text.length <= windowSize) {
      return scoreWindow(text);
    }

    var bestScore = 0;
    var bestHits = [];

    for (var i = 0; i < text.length; i += step) {
      var chunk = text.slice(i, i + windowSize);
      var r = scoreWindow(chunk);
      if (r.score > bestScore) {
        bestScore = r.score;
        bestHits = r.hits;
      }
      if (i + windowSize >= text.length) break;
    }

    return { score: bestScore, hits: bestHits };
  }

  function scoreDomain() {
    var host = location.hostname;
    var score = 0;
    var hits = [];

    var isGenericHost = R.genericPaasHosts.some(function (d) {
      return host === d || host.indexOf('.' + d) !== -1 || host.indexOf(d) !== -1;
    });

    var isOfficialBrandDomain = R.officialBrandDomains.some(function (d) {
      return host === d || host.endsWith('.' + d);
    });

    if (isGenericHost && !isOfficialBrandDomain) {
      score += 10;
      hits.push('generic_paas_host:' + host);
    }

    return { score: score, hits: hits };
  }

  function scoreBehavior() {
    var score = 0;
    var hits = [];

    if (beforeUnloadTrapDetected) {
      score += 12;
      hits.push('beforeunload_trap');
    }

    // fullscreen強制の検出(全画面オーバーレイで画面をロックしようとする典型パターン)
    if (document.fullscreenElement) {
      score += 6;
      hits.push('fullscreen_lock');
    }

    // フルスクリーンAPIの呼び出し試行(world-bridge.jsにブロックされ実際には
    // 全画面化されていない場合も含む)。クリック一発で発動するような正規サイトでは
    // まず見られない挙動のため、それ自体が強い裏付けシグナルになる。
    if (fullscreenAttemptDetected) {
      score += 10;
      hits.push('fullscreen_attempt_blocked');
    }

    if (pointerLockAttemptDetected) {
      score += R.structuralSignals.pointerLockAttempt;
      hits.push('pointer_lock_attempt');
    }

    if (keyboardLockAttemptDetected) {
      score += R.structuralSignals.keyboardLockAttempt;
      hits.push('keyboard_lock_attempt');
    }

    // 音声の無限ループ再生(警告音・恐怖演出)が実際に実行された場合の検出。
    // DOM未追加の<audio>要素でも、play()の呼び出し回数自体を監視しているため
    // 確実に捕捉できる。
    if (audioLoopDetected) {
      score += 12;
      hits.push('audio_repeated_playback:' + audioLoopCount);
    }

    return { score: score, hits: hits };
  }

  // Cookie同意バナー等の無害なdecoyページの裏で、フルビューポートの
  // 固定位置iframe(極端に高いz-index)を使って詐欺コンテンツを隠すパターンの検出。
  // all_frames:trueでiframe自体も個別にスキャンするのが主対策だが、構造面からも検出しておく。
  function scoreStructure() {
    var score = 0;
    var hits = [];
    var overlayIframeFound = false;
    var overlayAllowsFullscreen = false;
    var opaqueOrScriptedOverlaySource = false;

    var iframes = document.querySelectorAll('iframe');
    iframes.forEach(function (frame) {
      var style;
      try {
        style = window.getComputedStyle(frame);
      } catch (e) {
        return;
      }
      var rect = frame.getBoundingClientRect();
      var isFullViewport =
        rect.width >= window.innerWidth * 0.9 &&
        rect.height >= window.innerHeight * 0.9;
      var isFixedOrAbsolute = style.position === 'fixed' || style.position === 'absolute';
      var zIndexNum = parseInt(style.zIndex, 10);
      var isExtremeZIndex = !isNaN(zIndexNum) && zIndexNum >= 999999;
      var src = (frame.getAttribute('src') || '').trim().toLowerCase();
      var allowsFullscreen = frame.hasAttribute('allowfullscreen') ||
        /(^|[;\s])fullscreen([;\s]|$)/i.test(frame.getAttribute('allow') || '');
      var opaqueOrScriptedSource =
        src === '' || /^(about:|data:|blob:|filesystem:|javascript:)/i.test(src);

      if (isFullViewport && isFixedOrAbsolute && isExtremeZIndex) {
        overlayIframeFound = true;
        score += R.structuralSignals.fullscreenOverlayIframe;
        hits.push('fullscreen_overlay_iframe');
        if (allowsFullscreen) {
          overlayAllowsFullscreen = true;
          score += R.structuralSignals.iframeAllowsFullscreen;
          hits.push('overlay_iframe_allows_fullscreen');
        }
        if (opaqueOrScriptedSource) {
          opaqueOrScriptedOverlaySource = true;
          score += R.structuralSignals.opaqueOrScriptedIframeSource;
          hits.push('opaque_or_scripted_overlay_src');
        }
      }
    });

    // iframeの中身を検査できない/遅れる状況でも、全画面オーバーレイと操作ロックが
    // 同居していれば、正規サイトでは稀な危険な組み合わせとして親ページから警告できる。
    if (overlayIframeFound && (keyboardLockAttemptDetected || pointerLockAttemptDetected || fullscreenAttemptDetected)) {
      score += R.structuralSignals.overlayControlLockCombo;
      hits.push('overlay_plus_control_lock_combo');
    }

    if (window !== window.top) {
      score += R.structuralSignals.embeddedFrame;
      hits.push('embedded_in_iframe');
    }

    var scripts = document.querySelectorAll('script:not([src])');
    var inlineScriptCombined = '';
    scripts.forEach(function (s) {
      var scriptContent = s.textContent || '';
      inlineScriptCombined += ' ' + scriptContent;
      if (scriptContent.length > 500 && scriptContent.indexOf('atob(') !== -1 && scriptContent.indexOf('eval') !== -1) {
        score += 6;
        hits.push('obfuscated_eval_loader');
      }
    });

    if (/addEventListener\(\s*['"]ended['"][\s\S]{0,150}?\.play\(\s*\)/.test(inlineScriptCombined)) {
      score += 10;
      hits.push('audio_infinite_loop_trap');
    }

    var mediaElements = document.querySelectorAll('audio, video');
    var loopingMediaCount = 0;
    mediaElements.forEach(function (m) {
      if (m.loop === true || m.hasAttribute('loop')) loopingMediaCount++;
    });
    if (loopingMediaCount > 0) {
      score += 8;
      hits.push('looping_media_element:' + loopingMediaCount);
    }

    return { score: score, hits: hits };
  }

  function hasNoScriptingAtAll() {
    var hasScripts = document.querySelectorAll('script').length > 0;
    var hasIframes = document.querySelectorAll('iframe').length > 0;
    return !hasScripts && !hasIframes;
  }

  function isTrustedSearchEngine() {
    var host = location.hostname;
    return R.trustedSearchEngines.some(function (d) {
      return host === d || host.endsWith('.' + d);
    });
  }

  function isTrustedInstitutionalDomain() {
    var host = location.hostname;
    return R.trustedInstitutionalSuffixes.some(function (suffix) {
      return host.endsWith(suffix);
    });
  }

  // 信頼ドメインのスキップより優先される例外。動作確認・デモ目的で特定の
  // ページだけは通常通り判定したい場合に使う(rules.jsのforceCheckUrls参照)。
  function isForceCheckUrl() {
    var hostAndPath = location.hostname + location.pathname;
    return R.forceCheckUrls.some(function (prefix) {
      return hostAndPath.indexOf(prefix) === 0;
    });
  }

  // ==== 累積(繰り返し出現)スコアリング ====
  // IPAの注意喚起にもある通り、サポート詐欺ページは「次から次へとメッセージを
  // 表示」する、すなわち同じ(または類似の)警告要素が時間を置いて繰り返し
  // 出現するのが典型的な特徴。1回ごとのチェックでは閾値未満でも、同じ検出項目が
  // 複数回のチェックにまたがって繰り返し観測された場合は、それ自体を「しつこさ」
  // のシグナルとして加点する。これにより、1回のスナップショットだけでは判定し
  // づらい、じわじわ追加されていくタイプの詐欺ページにも対応しやすくする。
  var hitObservationCounts = {}; // hitキー(カテゴリ部分のみ正規化) -> 観測回数

  function normalizeHitKey(hit) {
    // 'phone_numbers:3' や 'authority:microsoft' のように値部分が変動する
    // ものは、コロン以前のカテゴリ名だけを取り出して同一視する
    var idx = hit.indexOf(':');
    return idx === -1 ? hit : hit.slice(0, idx);
  }

  // 累積対象に含めるキーのホワイトリスト方式に変更。
  // 当初は「除外リスト」方式(ドメイン名だけ除外)だったが、通常の記事ページでも
  // 本文のブランド名・脅迫文言等(authority/threat/urgency/contact等)は最初から
  // 最後まで画面に表示され続けるだけで、消えて再び現れる訳ではない。これを
  // 「繰り返し出現」として加点してしまうと、詳しく解説された正規のセキュリティ
  // ブログ記事等まで誤検知してしまうことが実際の検証で判明した(LANSCOPE社の
  // 解説記事で、静的な内容が複数回観測されただけで+64点も積み上がり閾値を
  // 超えてしまった)。
  // 一方、beforeunload濫用・フルスクリーン再試行・音声ループ等の「挙動」は、
  // 正規ページでは通常一度きりかゼロ回であり、何度も観測されること自体が
  // 「しつこく繰り返している」という真に動的なシグナルになる。そのため
  // 累積ボーナスは、これらの挙動/構造シグナルに限定する。
  var REPETITION_ALLOWED_KEYS = [
    'beforeunload_trap',
    'fullscreen_lock',
    'audio_repeated_playback',
    'looping_media_element',
    'audio_infinite_loop_trap',
    'fullscreen_overlay_iframe',
    'overlay_plus_control_lock_combo',
    'keyboard_lock_attempt',
    'pointer_lock_attempt',
    'obfuscated_eval_loader'
  ];

  function computeRepetitionBonus(currentHits) {
    var uniqueKeysThisCheck = [];
    currentHits.forEach(function (h) {
      var key = normalizeHitKey(h);
      if (REPETITION_ALLOWED_KEYS.indexOf(key) === -1) return;
      if (uniqueKeysThisCheck.indexOf(key) === -1) {
        uniqueKeysThisCheck.push(key);
      }
    });

    uniqueKeysThisCheck.forEach(function (key) {
      hitObservationCounts[key] = (hitObservationCounts[key] || 0) + 1;
    });

    var bonus = 0;
    var hits = [];
    uniqueKeysThisCheck.forEach(function (key) {
      var count = hitObservationCounts[key];
      // 3回目以降の再出現から加点開始(初回・2回目は様子見扱い)、
      // 1項目あたりの加点上限を設けてキャップする
      if (count >= 3) {
        var add = Math.min((count - 2) * 4, 16);
        bonus += add;
        hits.push('recurring:' + key + 'x' + count + '(+' + add + ')');
      }
    });

    return { bonus: bonus, hits: hits };
  }

  function runCheck() {
    var forceCheck = isForceCheckUrl();
    var skipContentScoring = !forceCheck && (isTrustedSearchEngine() || isTrustedInstitutionalDomain());
    var text = getVisibleText() + ' \n ' + getInlineScriptText();
    var c = skipContentScoring ? { score: 0, hits: [] } : scoreContent(text);

    // サポート詐欺の典型的な手口(偽ポップアップ表示・離脱妨害・音声ループ・
    // フルスクリーン強制等)は、ほぼ例外なく能動的なJavaScriptを必要とする。
    // scriptタグもiframeも一切存在しない完全な静的ページは相対的にリスクが
    // 低いと考えられるため、コンテンツスコアに軽い減点係数をかける(0にはせず、
    // 極端に高いスコアであれば検出される余地は残す)。
    if (!skipContentScoring && c.score > 0 && hasNoScriptingAtAll()) {
      var discounted = Math.round(c.score * 0.6);
      if (discounted < c.score) {
        c.hits.push('no_scripting_discount:' + c.score + '->' + discounted);
        c.score = discounted;
      }
    }
    var d = scoreDomain();
    var b = scoreBehavior();
    var st = scoreStructure();
    var subtotal = c.score + d.score + b.score + st.score;
    var subtotalHits = c.hits.concat(d.hits, b.hits, st.hits);

    var rep = computeRepetitionBonus(subtotalHits);
    var total = subtotal + rep.bonus;
    var hits = subtotalHits.concat(rep.hits);

    chrome.runtime.sendMessage({
      type: 'SCORE_UPDATE',
      url: location.href,
      host: location.hostname,
      score: total,
      hits: hits
    });

    // ==== 閾値判定: テキストだけの高得点と、裏付けのある高得点を区別する ====
    // 警察庁・大学・セキュリティベンダー等が詐欺の手口を詳しく解説するページは、
    // 正当な理由でブランド名・脅迫文言・連絡先等を多用するため、コンテンツ判定
    // だけでも50点を超えてしまうことがある(実際に複数の公式サイトで確認された)。
    // これをドメインのホワイトリストで個別に潰す方式は際限がないため、より
    // 一般的な区別として「実際に不審な挙動・構造が伴っているか」を要求する
    // ことにした。本物の詐欺ページは離脱妨害・フルスクリーン強制・音声ループ等の
    // 能動的な挙動を伴うことがほとんどだが、解説記事は文章のみで、これらの
    // 挙動は一切発生しない。
    // ただし、JSを一切使わない極めて単純なテキスト+電話番号型の詐欺ページにも
    // 対応できるよう、コンテンツスコア単体が極めて高い場合は、裏付けなしでも
    // 検出する。
    var HIGH_CONFIDENCE_CONTENT_THRESHOLD = 80;
    var hasCorroboration = (d.score > 0) || (b.score > 0) || (st.score > 0);
    var meetsThreshold =
      c.score >= HIGH_CONFIDENCE_CONTENT_THRESHOLD ||
      (total >= R.threshold && hasCorroboration);

    if (meetsThreshold) {
      if (window !== window.top) {
        try {
          chrome.runtime.sendMessage({
            type: 'FRAME_SCAM_DETECTED',
            score: total,
            hits: hits,
            url: location.href,
            host: location.hostname
          });
        } catch (e) {
          /* ignore */
        }
      }
      maybeShowOverlay(total, hits);
    } else if (!flaggedAsScam) {
      // 安全と判定できた場合、world-bridge.jsに「猶予期間中のフルスクリーンブロック」
      // を早期解除してよいと伝える(誤ってブロックし続けて正規サイトのフルスクリーン
      // 機能を壊さないようにするため)
      try {
        window.postMessage({ type: '__SCAM_DETECTOR_CLEAR__' }, '*');
      } catch (e) {
        /* ignore */
      }
    }
  }

  function maybeShowOverlay(score, hits) {
    if (document.getElementById('__scam_detector_overlay__')) return;

    flaggedAsScam = true;

    // beforeunload無効化 + 今後のrequestFullscreen()ブロックをMAIN worldに指示
    try {
      window.postMessage({ type: '__SCAM_DETECTOR_NEUTRALIZE__' }, '*');
    } catch (e) {
      /* ignore */
    }

    exitFullscreenIfNeeded();
    forceCursorVisible();

    chrome.storage.local.get(['whitelist'], function (res) {
      var whitelist = res.whitelist || [];
      if (whitelist.indexOf(location.hostname) !== -1) return;
      renderOverlay(score, hits);
    });
  }

  function exitFullscreenIfNeeded() {
    if (!flaggedAsScam) return; // 通常サイトの正当なフルスクリーン利用は妨げない
    try {
      if (document.fullscreenElement || document.webkitFullscreenElement) {
        (document.exitFullscreen || document.webkitExitFullscreen).call(document);
      }
    } catch (e) {
      /* ignore */
    }
  }

  // cursor:none 等でカーソルを非表示にし、フルスクリーンと組み合わせて
  // 「画面が固まった/操作できない」と錯覚させる手口への対策。
  // !important付きの強いCSSでカーソル表示を強制的に復元する。
  function forceCursorVisible() {
    if (document.getElementById('__scam_detector_cursor_fix__')) return;
    var style = document.createElement('style');
    style.id = '__scam_detector_cursor_fix__';
    style.textContent =
      'html, body, * { cursor: auto !important; } ' +
      '#__scam_detector_overlay__, #__scam_detector_overlay__ * { cursor: default !important; } ' +
      '#__scam_detector_overlay__ button { cursor: pointer !important; }';
    (document.head || document.documentElement).appendChild(style);
  }

  // ページが再度フルスクリーンに入ろうとする/cursor:noneを再適用してくる
  // ケースに備え、継続的に監視して解除する。
  document.addEventListener('fullscreenchange', exitFullscreenIfNeeded);
  document.addEventListener('webkitfullscreenchange', exitFullscreenIfNeeded);

  function renderOverlay(score, hits) {
    var overlay = document.createElement('div');
    overlay.id = '__scam_detector_overlay__';
    overlay.style.cssText =
      'position:fixed;top:0;left:0;width:100%;height:100%;' +
      'background:rgba(10,10,20,0.96);z-index:2147483647;' +
      'display:flex;align-items:center;justify-content:center;' +
      'font-family:-apple-system,"Hiragino Sans","Yu Gothic",sans-serif;';

    var box = document.createElement('div');
    box.style.cssText =
      'max-width:480px;width:90%;background:#fff;border-radius:14px;' +
      'padding:32px;box-shadow:0 10px 40px rgba(0,0,0,0.5);text-align:center;';

    var hitsShown = hits.slice(0, 6).join(' / ');

    box.innerHTML =
      '<div style="font-size:48px;line-height:1;">\u26A0\uFE0F</div>' +
      '<h2 style="color:#c0392b;margin:14px 0 8px;font-size:20px;">' +
        'このページはサポート詐欺サイトの可能性があります' +
      '</h2>' +
      '<p style="color:#333;font-size:14px;line-height:1.7;text-align:left;">' +
        '偽のセキュリティ警告・サポート詐欺によく見られる特徴が検出されました(検出スコア: ' + score + ')。' +
        '<br><br>' +
        '<b>表示されている電話番号には絶対に連絡しないでください。</b>' +
        '<br>' +
        'Microsoft・Apple・各種セキュリティソフトの本物の警告は、ブラウザ上にこのような形式で表示されることはなく、サポートへの電話を強要することもありません。' +
      '</p>' +
      '<div style="margin-top:22px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">' +
        '<button id="__scam_close_tab__" style="background:#c0392b;color:#fff;border:none;' +
          'padding:11px 18px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:bold;">' +
          'このタブを閉じる' +
        '</button>' +
        '<button id="__scam_dismiss__" style="background:#eee;color:#333;border:none;' +
          'padding:11px 18px;border-radius:8px;cursor:pointer;font-size:14px;">' +
          '無視して閲覧を続ける' +
        '</button>' +
      '</div>' +
      '<p style="margin-top:16px;font-size:11px;color:#999;">検出理由: ' + hitsShown + '</p>';

    overlay.appendChild(box);
    document.documentElement.appendChild(overlay);

    document.getElementById('__scam_close_tab__').onclick = function () {
      var btn = document.getElementById('__scam_close_tab__');
      btn.disabled = true;
      btn.textContent = '閉じています...';

      try {
        window.postMessage({ type: '__SCAM_DETECTOR_NEUTRALIZE__' }, '*');
      } catch (e) {
        /* ignore */
      }

      function requestClose() {
        try {
          chrome.runtime.sendMessage({ type: 'CLOSE_TAB' });
        } catch (e) {
          /* extension context invalidated 等。ポップアップから強制終了を案内する */
        }
      }

      requestClose();
      // ページ側の重い setInterval 等で初回が処理待ちになるケースに備え、
      // 念のため少し間を置いて再送する
      setTimeout(requestClose, 400);

      setTimeout(function () {
        if (document.getElementById('__scam_detector_overlay__')) {
          btn.disabled = false;
          btn.textContent = 'このタブを閉じる(拡張機能アイコン→強制終了も使えます)';
        }
      }, 2500);
    };
    document.getElementById('__scam_dismiss__').onclick = function () {
      overlay.parentNode.removeChild(overlay);
    };
  }

  // 初回チェック + 動的に文言が描画されるケースに対応するため数回リトライ
  var intervalId = setInterval(function () {
    runCheck();
    checksRun++;
    if (checksRun >= MAX_CHECKS) {
      clearInterval(intervalId);
    }
  }, CHECK_INTERVAL_MS);

  runCheck();
})();
