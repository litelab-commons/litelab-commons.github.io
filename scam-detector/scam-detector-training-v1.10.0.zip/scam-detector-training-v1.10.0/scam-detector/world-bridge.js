// world-bridge.js
// MAIN worldで動作し、ページが設定する離脱妨害・全画面化・操作ロック・音声ループを
// 早期に観測/抑止する。content.jsにはpostMessageで観測結果だけを通知する。
(function () {
  'use strict';

  if (window.__scamBridgeInstalled) return;
  window.__scamBridgeInstalled = true;

  var neutralized = false;
  var realHandler = null;
  var trackedListeners = [];
  var GRACE_PERIOD_MS = 2200;
  var fullscreenBlockState = 'pending'; // pending | cleared | neutralized
  var notified = {};

  function notify(type, extra) {
    if (notified[type]) return;
    notified[type] = true;
    try {
      var payload = { type: type };
      if (extra) {
        Object.keys(extra).forEach(function (key) { payload[key] = extra[key]; });
      }
      window.postMessage(payload, '*');
    } catch (e) {
      /* ignore */
    }
  }

  // ---- beforeunload濫用対策 ----
  try {
    Object.defineProperty(window, 'onbeforeunload', {
      configurable: true,
      get: function () { return realHandler; },
      set: function (fn) { realHandler = typeof fn === 'function' ? fn : null; }
    });
  } catch (e) {
    /* ignore */
  }

  window.addEventListener('beforeunload', function (e) {
    if (neutralized) return;
    if (typeof realHandler === 'function') {
      var result = realHandler(e);
      if (result !== undefined) e.returnValue = result;
    }
  }, true);

  var originalAdd = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, listener, options) {
    if (type === 'beforeunload' && this === window) {
      trackedListeners.push({ target: this, listener: listener, options: options });
    }
    return originalAdd.call(this, type, listener, options);
  };

  // ---- フルスクリーン/ポインターロック対策 ----
  var fullscreenMethodNames = [
    'requestFullscreen', 'webkitRequestFullscreen', 'webkitRequestFullScreen',
    'mozRequestFullScreen', 'msRequestFullscreen'
  ];
  var originalFullscreenMethods = {};
  fullscreenMethodNames.forEach(function (name) {
    if (Element.prototype[name]) originalFullscreenMethods[name] = Element.prototype[name];
  });
  var originalRequestPointerLock = Element.prototype.requestPointerLock;

  function blockFullscreen() {
    var blocked = function () {
      notify('__SCAM_DETECTOR_FULLSCREEN_ATTEMPT__');
      return Promise.resolve();
    };
    fullscreenMethodNames.forEach(function (name) {
      if (originalFullscreenMethods[name]) {
        try { Element.prototype[name] = blocked; } catch (e) { /* ignore */ }
      }
    });
    if (originalRequestPointerLock) {
      try {
        Element.prototype.requestPointerLock = function () {
          notify('__SCAM_DETECTOR_POINTER_LOCK_ATTEMPT__');
          return undefined;
        };
      } catch (e) { /* ignore */ }
    }
  }

  function releaseFullscreenBlock() {
    fullscreenMethodNames.forEach(function (name) {
      if (originalFullscreenMethods[name]) {
        try { Element.prototype[name] = originalFullscreenMethods[name]; } catch (e) { /* ignore */ }
      }
    });
    if (originalRequestPointerLock) {
      try { Element.prototype.requestPointerLock = originalRequestPointerLock; } catch (e) { /* ignore */ }
    }
  }

  // ---- Keyboard Lock API対策 ----
  // navigator.keyboard.lock() はキーボードの操作を奪うため、サポート詐欺での
  // 「Escやショートカットを効かせない」演出と組み合わさると危険度が高い。
  var keyboardApi = navigator.keyboard;
  var originalKeyboardLock = keyboardApi && typeof keyboardApi.lock === 'function' ? keyboardApi.lock : null;
  var keyboardLockPatched = false;

  function setKeyboardLockBlocked(blocked) {
    if (!keyboardApi || !originalKeyboardLock) return;
    try {
      if (blocked) {
        keyboardApi.lock = function () {
          notify('__SCAM_DETECTOR_KEYBOARD_LOCK_ATTEMPT__');
          return Promise.resolve();
        };
        keyboardLockPatched = true;
      } else if (keyboardLockPatched) {
        keyboardApi.lock = originalKeyboardLock;
        keyboardLockPatched = false;
      }
    } catch (e) {
      // ブラウザ実装によってはプロパティが書換不可。観測不能でもページは壊さない。
    }
  }

  blockFullscreen();
  setKeyboardLockBlocked(true);

  var graceTimer = setTimeout(function () {
    if (fullscreenBlockState === 'pending') {
      fullscreenBlockState = 'cleared';
      releaseFullscreenBlock();
      setKeyboardLockBlocked(false);
    }
  }, GRACE_PERIOD_MS);

  function clearBlocksIfPending() {
    if (fullscreenBlockState === 'pending') {
      fullscreenBlockState = 'cleared';
      clearTimeout(graceTimer);
      releaseFullscreenBlock();
      setKeyboardLockBlocked(false);
    }
  }

  function neutralizePermanently() {
    fullscreenBlockState = 'neutralized';
    clearTimeout(graceTimer);
    blockFullscreen();
    setKeyboardLockBlocked(true);
  }

  function neutralize() {
    if (neutralized) return;
    neutralized = true;
    realHandler = null;
    trackedListeners.forEach(function (entry) {
      try { entry.target.removeEventListener('beforeunload', entry.listener, entry.options); } catch (e) { /* ignore */ }
    });
    var originalSetInterval = window.setInterval;
    window.setInterval = function (fn, delay) {
      var safeDelay = (typeof delay === 'number' && delay < 50) ? 50 : delay;
      return originalSetInterval.call(window, fn, safeDelay);
    };
    neutralizePermanently();
  }

  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data) return;
    if (e.data.type === '__SCAM_DETECTOR_NEUTRALIZE__') {
      neutralize();
    } else if (e.data.type === '__SCAM_DETECTOR_CLEAR__') {
      clearBlocksIfPending();
    }
  });

  // ---- 音声の無限ループ再生監視 ----
  try {
    var audioPlayCounts = new WeakMap();
    var notifiedAudioLoop = false;
    var originalMediaPlay = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function () {
      try {
        var count = (audioPlayCounts.get(this) || 0) + 1;
        audioPlayCounts.set(this, count);
        if (count >= 3 && !notifiedAudioLoop) {
          notifiedAudioLoop = true;
          notify('__SCAM_DETECTOR_AUDIO_LOOP__', { count: count });
        }
      } catch (e) { /* ignore */ }
      return originalMediaPlay.apply(this, arguments);
    };
  } catch (e) {
    /* ignore */
  }
})();
