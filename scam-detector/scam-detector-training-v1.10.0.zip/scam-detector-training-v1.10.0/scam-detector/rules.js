// rules.js
// 判定ルール定義。判定補助ツールと同様の三層スコアリング方式。
// layer1: コンテンツ(テキスト)ヒューリスティック
// layer2: ドメイン/URLヒューリスティック
// layer3: 外部API連携(将来拡張・background.js内でスタブ実装)

var SCAM_RULES = {
  threshold: 50,

  // 親ページ側の構造・操作妨害シグナル。単独では警告に達しないようにし、
  // 全画面iframeと操作ロックが同時にある場合だけ強く加点する。
  structuralSignals: {
    fullscreenOverlayIframe: 18,
    iframeAllowsFullscreen: 6,
    opaqueOrScriptedIframeSource: 14,
    embeddedFrame: 4,
    overlayControlLockCombo: 18,
    keyboardLockAttempt: 20,
    pointerLockAttempt: 10
  },

  // ==== カテゴリベースの判定(v1.6〜) ====
  // 「特定の言い回し1つに強く依存する」完全一致リストだと、表現が少し変わるだけで
  // すり抜けてしまう(実例: 「個人情報が盗まれ」では拾えるが「個人情報が危険に
  // さらされ」は拾えない 等)。そこで、フレーズ全体ではなく短い「概念の断片」を
  // 複数カテゴリに分けて持たせ、(a)断片レベルの部分一致でゆらぎに強くする、
  // (b)1カテゴリだけがヒットしてもさほど高得点にはせず、複数カテゴリが同時に
  // 出現する(=「まんべんなく」要素が揃っている)ことを加点条件にすることで、
  // 単語の偶然の一致による誤検知を抑えつつ、未知の言い回しの亜種にも対応できる
  // ようにする。これはスパム/フィッシング分類で使われる「カテゴリ網羅性スコア
  // リング」の考え方を簡易的に取り入れたもの。
  categories: {
    // 権威・ブランドの詐称(実在の社名や、それらしい一般名称のサポート窓口を騙る)
    authority: {
      weight: 15,
      tokens: [
        'windows defender', 'windows security', 'windows_defender',
        'microsoft', 'windowsサポート', 'windowsセキュリティ', 'マイクロソフト',
        'apple support', 'appleサポート', 'norton', 'mcafee', 'trend micro',
        'セキュリティセンター', 'パソコンサポート', 'テクニカルサポート',
        'カスタマーサポート', 'サポートセンター', '正規サポート'
      ]
    },
    // 恐怖・脅迫(ウイルス感染、情報漏洩、システム障害等を主張する表現の断片)
    threat: {
      weight: 14,
      tokens: [
        '感染', 'ウイルス', 'スパイウェア', 'マルウェア', 'トロイの木馬',
        '個人情報', '盗まれ', '危険にさらさ', '侵害', '流出',
        '銀行のログイン', 'クレジットカード', 'identity theft', 'infected',
        'アクセスが制限', 'アクセスはブロック', 'アクセスをブロック',
        '無効化', '無効になっ', 'クラッシュ', 'システムが破損',
        '破損しました', 'データが破損', 'ファイルを削除', '保護するため'
      ]
    },
    // 緊急性・行動の強制(冷静に判断する時間を与えない言い回し)
    urgency: {
      weight: 8,
      tokens: [
        '直ちに', '今すぐ', 'すぐに', 'immediately', 'できるだけ早く',
        '閉じないでください', '閉じない', '操作しないでください',
        '電源を切らないでください', '電源を切らない', '再起動してください',
        '再起動したり', 'このウィンドウを閉じる'
      ]
    },
    // 連絡の要求(電話・問い合わせへの誘導表現)
    contact: {
      weight: 10,
      tokens: [
        'ご連絡ください', '連絡してください', 'お電話ください', 'call now',
        '問い合わせ先サポート', '無料通話', 'フリーダイヤル', 'お問い合わせ',
        'サポートに連絡', '安全に戻る'
      ]
    }
  },

  // 1ウィンドウ内で同時に出現したカテゴリ数に応じたボーナス(最も条件を満たす
  // 最大のものを1つだけ適用)。「まんべんなく出現」を加点するための仕組み。
  comboBonus: [
    { min: 4, bonus: 35 },
    { min: 3, bonus: 20 },
    { min: 2, bonus: 8 }
  ],

  // ==== 旧来の完全フレーズ一致リスト(参考・後方互換用に残置) ====
  // 上記categoriesに統合済みのため、現在のcontent.jsの判定ロジックでは
  // 使用していない。
  brandKeywords: [
    'windows defender', 'windows security', 'windows_defender',
    'microsoft support', 'microsoftサポート', 'windowsサポート',
    'windowsセキュリティ', 'マイクロソフト', 'apple support',
    'appleサポート', 'norton', 'mcafee', 'セキュリティセンター', 'trend micro'
  ],

  urgencyKeywords: [
    '直ちに', '今すぐ', 'すぐに', 'immediately', 'call now',
    'do not close', 'このウィンドウを閉じる', '再起動したり',
    '閉じないでください', '操作しないでください', 'できるだけ早く',
    '電源を切らないでください', '電源を切らない', '再起動してください',
    'ご連絡ください', '連絡してください', 'お電話ください',
    '問い合わせ先サポート', '無料通話', '安全に戻る'
  ],

  threatKeywords: [
    'ウイルスが検出', '個人情報が盗まれ', 'アドウェア',
    'identity theft', 'infected', '盗まれました',
    '銀行のログイン', 'クレジットカード', 'アクセスが制限',
    '無効化されました', 'アクセスをブロック',
    'ウイルスに感染', 'ウイルス感染', '感染を検出',
    'クラッシュしました', 'システムが破損', '破損しました',
    'ファイルを削除', 'コンピュータを保護するため', 'データが破損'
  ],

  phoneRegex: /(\(?0\d{1,4}\)?[-\s]?\d{2,5}[-\s]?\d{3,5}[-\s]?\d{0,4}|\+?\d{1,3}[-\s]\d{2,4}[-\s]\d{3,4}[-\s]\d{3,4})/g,

  // 「エラーコード」の直後に続く実際のコード表記は #0x268d3 / 0XDMC29 のように
  // 記号(#等)を含む場合があるため、英数字に限定せず広めに(空白以外の3文字以上)で
  // マッチさせる。
  errorCodeRegex: /エラーコード[:\s]*\S{3,}/,

  genericPaasHosts: [
    'amplifyapp.com', 'herokuapp.com', 'vercel.app', 'netlify.app',
    'firebaseapp.com', 'web.app', 'glitch.me', '000webhostapp.com',
    'weebly.com', 'wixsite.com', 'github.io', 'pages.dev', 'azurewebsites.net'
  ],

  officialBrandDomains: [
    'microsoft.com', 'live.com', 'apple.com', 'google.com', 'norton.com', 'mcafee.com'
  ],

  // 検索エンジンのSERP自体が詐欺ページ本体になることは実質ない。
  // 様々な検索結果スニペットに用語が分散して誤検知するのを防ぐため、
  // これらのドメインではコンテンツ判定(layer1)をスキップする。
  trustedSearchEngines: [
    'google.com', 'google.co.jp', 'bing.com', 'search.yahoo.co.jp', 'yahoo.co.jp',
    'duckduckgo.com', 'baidu.com', 'yandex.com', 'ecosia.org', 'so.com',
    'search.brave.com', 'startpage.com'
  ],

  // 警察庁・IPA・消費者庁等の公的機関や、大学のサイバーセキュリティセンター等の
  // 教育機関が詐欺の手口を詳しく解説するページは、実在の電話番号・脅迫的な
  // 引用文・複数のブランド名等を正当な理由で多用するため、コンテンツ判定が
  // 誤検知しやすい。.go.jp/.lg.jp(政府・地方自治体)、.ac.jp(大学等の認定教育
  // 機関)は日本国内で発行が厳格に管理されており実質なりすまし不可能なため、
  // TLD単位でコンテンツ判定(layer1)をスキップする。
  trustedInstitutionalSuffixes: ['.go.jp', '.lg.jp', '.ac.jp'],

  // 上記の信頼ドメインスキップの「例外」。動作確認・デモ目的で、特定のページに
  // ついては信頼ドメインであっても通常通りコンテンツ判定を行いたい場合に
  // ここへ追加する。ホスト名+パスの前方一致で判定する。
  // (例: IPA公式の「偽セキュリティ警告画面の閉じ方体験サイト」は内容が実際の
  // 詐欺ページとほぼ同一であり、判定ロジックが正しく動作するかのテストに
  // 適しているため、.go.jpの信頼スキップ対象から除外している)
  forceCheckUrls: [
    'www.ipa.go.jp/security/anshin/measures/fa-experience.html'
  ],
};

if (typeof module !== 'undefined') {
  module.exports = SCAM_RULES;
}
