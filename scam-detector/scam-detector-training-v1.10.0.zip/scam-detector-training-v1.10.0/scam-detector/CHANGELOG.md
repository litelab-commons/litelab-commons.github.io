# Change Log

## v1.10.0 — 改ざん正規サイト上のサポート詐欺 iframe 対策

### 修正

- 不透明オリジンの子フレームに対し、`match_origin_as_fallback` を使って content script を注入。
- 全画面固定・巨大 z-index・fullscreen 許可を持つ iframe を構造シグナルとして評価。
- `navigator.keyboard.lock()` と `requestPointerLock()` の試行を観測し、猶予期間中は抑止。
- 全画面 iframe と操作ロックが同時にある場合、iframe 内を取得できない場合でも親ページ側で警告できる合成スコアを追加。
- 子フレームでの確定検知を background 経由でトップフレームに伝達し、タブ全体を覆う警告を表示。

### ねらい

正規URLの企業サイトが改ざんされ、全画面 iframe で偽の警告画面を重ねるケースを対象にする。URLの正規性では安全判定せず、画面構造と操作妨害の組み合わせを評価する。
