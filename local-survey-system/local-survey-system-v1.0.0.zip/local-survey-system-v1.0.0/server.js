const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || '0.0.0.0';

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// In-memory store
const store = {
  survey: {
    title: '',
    description: '',
    questions: [],
    isOpen: false,
    oneSubmitPerSession: true,
  },
  answers: [],
  nextAnswerId: 1,
};

// --- Survey routes ---

app.get('/api/survey', (req, res) => {
  res.json(store.survey);
});

app.put('/api/survey', (req, res) => {
  const { title, description, questions, isOpen, oneSubmitPerSession } = req.body;
  if (typeof title !== 'string' || !Array.isArray(questions)) {
    return res.status(400).json({ error: 'Invalid payload' });
  }
  if (title.trim().length > 120 || String(description || '').length > 1000 || questions.length > 50) {
    return res.status(400).json({ error: 'Survey is too large' });
  }
  for (const q of questions) {
    if (!q.id || !q.type || typeof q.label !== 'string') {
      return res.status(400).json({ error: 'Each question needs id, type, label' });
    }
    if (!['text', 'radio', 'checkbox', 'scale'].includes(q.type)) {
      return res.status(400).json({ error: `Unsupported question type: ${q.type}` });
    }
    if (q.label.length > 300) {
      return res.status(400).json({ error: 'Question label is too long' });
    }
    if (['radio', 'checkbox'].includes(q.type) && (!Array.isArray(q.options) || q.options.length === 0)) {
      return res.status(400).json({ error: `Question "${q.label}" needs options` });
    }
    if (Array.isArray(q.options) && (q.options.length > 30 || q.options.some(opt => typeof opt !== 'string' || opt.length > 120))) {
      return res.status(400).json({ error: `Question "${q.label}" has invalid options` });
    }
  }
  store.survey = { title, description: description || '', questions, isOpen: !!isOpen, oneSubmitPerSession: oneSubmitPerSession !== false };
  res.json(store.survey);
});

// --- Answer routes ---

app.post('/api/answers', (req, res) => {
  if (!store.survey.isOpen) {
    return res.status(403).json({ error: 'Survey is closed' });
  }
  const { responses } = req.body;
  if (!responses || typeof responses !== 'object') {
    return res.status(400).json({ error: 'Invalid responses' });
  }
  if (store.answers.length >= 1000) {
    return res.status(409).json({ error: 'Answer limit reached' });
  }
  const normalizedResponses = {};
  for (const q of store.survey.questions) {
    const value = responses[q.id];
    if (q.type === 'checkbox') {
      normalizedResponses[q.id] = Array.isArray(value)
        ? value.map(v => String(v).slice(0, 500)).slice(0, 30)
        : [];
    } else {
      normalizedResponses[q.id] = value === undefined || value === null ? '' : String(value).slice(0, 2000);
    }
  }
  const entry = {
    id: store.nextAnswerId++,
    submittedAt: new Date().toISOString(),
    responses: normalizedResponses,
  };
  store.answers.push(entry);
  res.status(201).json({ id: entry.id });
});

app.get('/api/answers', (req, res) => {
  const aggregates = {};
  for (const q of store.survey.questions) {
    if (q.type === 'radio' || q.type === 'checkbox') {
      const counts = {};
      for (const opt of (q.options || [])) counts[opt] = 0;
      for (const ans of store.answers) {
        const val = ans.responses[q.id];
        if (Array.isArray(val)) {
          for (const v of val) { if (counts[v] !== undefined) counts[v]++; }
        } else if (val !== undefined && val !== '') {
          if (counts[val] !== undefined) counts[val]++;
        }
      }
      aggregates[q.id] = counts;
    } else if (q.type === 'scale') {
      const vals = store.answers
        .map(a => Number(a.responses[q.id]))
        .filter(v => !isNaN(v) && v >= 1);
      aggregates[q.id] = {
        count: vals.length,
        avg: vals.length ? (vals.reduce((s, v) => s + v, 0) / vals.length).toFixed(2) : null,
        distribution: [1, 2, 3, 4, 5].reduce((acc, n) => {
          acc[n] = vals.filter(v => v === n).length;
          return acc;
        }, {}),
      };
    }
  }
  res.json({ answers: store.answers, aggregates, total: store.answers.length });
});

app.delete('/api/answers', (req, res) => {
  store.answers = [];
  store.nextAnswerId = 1;
  res.json({ ok: true });
});

// Serve pages
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'survey.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`Survey server running on http://${HOST}:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin`);
  console.log(`Client: http://<your-ip>:${PORT}/`);
  console.log('Note: This tool has no authentication. Use it only on a trusted local network.');
});
