const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, 'data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const defaultStore = {
  survey: {
    title: '',
    description: '',
    questions: [],
    isOpen: false,
    oneSubmitPerSession: true,
  },
  answers: [],
  nextAnswerId: 1,
  presets: Array(5).fill(null),
};

const store = loadStore();

function loadStore() {
  const fresh = structuredClone(defaultStore);
  try {
    if (!fs.existsSync(STORE_PATH)) return fresh;
    const saved = JSON.parse(fs.readFileSync(STORE_PATH, 'utf8'));
    return {
      ...fresh,
      ...saved,
      survey: { ...fresh.survey, ...(saved.survey || {}) },
      answers: Array.isArray(saved.answers) ? saved.answers : [],
      nextAnswerId: Number.isInteger(saved.nextAnswerId) ? saved.nextAnswerId : 1,
      presets: normalizePresets(saved.presets),
    };
  } catch (err) {
    console.error(`Failed to load ${STORE_PATH}:`, err.message);
    return fresh;
  }
}

function saveStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2));
}

function normalizePresets(presets) {
  const slots = Array(5).fill(null);
  if (!Array.isArray(presets)) return slots;
  for (let i = 0; i < Math.min(5, presets.length); i++) {
    slots[i] = presets[i] || null;
  }
  return slots;
}

function validateSurveyPayload(payload) {
  const { title, description, questions } = payload;
  if (typeof title !== 'string' || !Array.isArray(questions)) {
    return 'Invalid payload';
  }
  if (title.trim().length > 120 || String(description || '').length > 1000 || questions.length > 50) {
    return 'Survey is too large';
  }
  for (const q of questions) {
    if (!q.id || !q.type || typeof q.label !== 'string') {
      return 'Each question needs id, type, label';
    }
    if (!['text', 'radio', 'checkbox', 'scale'].includes(q.type)) {
      return `Unsupported question type: ${q.type}`;
    }
    if (q.label.length > 300) {
      return 'Question label is too long';
    }
    if (['radio', 'checkbox'].includes(q.type) && (!Array.isArray(q.options) || q.options.length === 0)) {
      return `Question "${q.label}" needs options`;
    }
    if (Array.isArray(q.options) && (q.options.length > 30 || q.options.some(opt => typeof opt !== 'string' || opt.length > 120))) {
      return `Question "${q.label}" has invalid options`;
    }
  }
  return null;
}

function normalizeSurvey(payload) {
  return {
    title: payload.title,
    description: payload.description || '',
    questions: payload.questions,
    isOpen: !!payload.isOpen,
    oneSubmitPerSession: payload.oneSubmitPerSession !== false,
  };
}

function getAggregates() {
  const aggregates = {};
  for (const q of store.survey.questions) {
    if (q.type === 'radio' || q.type === 'checkbox') {
      const counts = {};
      for (const opt of (q.options || [])) counts[opt] = 0;
      for (const ans of store.answers) {
        const val = ans.responses[q.id];
        if (Array.isArray(val)) {
          for (const v of val) { if (counts[v] !== undefined) counts[v]++; }
        } else if (val !== undefined && val !== '') {
          if (counts[val] !== undefined) counts[val]++;
        }
      }
      aggregates[q.id] = counts;
    } else if (q.type === 'scale') {
      const vals = store.answers
        .map(a => Number(a.responses[q.id]))
        .filter(v => !isNaN(v) && v >= 1);
      aggregates[q.id] = {
        count: vals.length,
        avg: vals.length ? (vals.reduce((s, v) => s + v, 0) / vals.length).toFixed(2) : null,
        distribution: [1, 2, 3, 4, 5].reduce((acc, n) => {
          acc[n] = vals.filter(v => v === n).length;
          return acc;
        }, {}),
      };
    }
  }
  return aggregates;
}

function formatAnswerValue(value) {
  if (Array.isArray(value)) return value.join(', ');
  if (value === undefined || value === null || value === '') return '-';
  return String(value);
}

function buildResultsText() {
  const aggregates = getAggregates();
  const lines = [];
  lines.push(`アンケート結果: ${store.survey.title || 'アンケート'}`);
  if (store.survey.description) {
    lines.push('');
    lines.push(store.survey.description);
  }
  lines.push('');
  lines.push(`保存日時: ${new Date().toLocaleString('ja-JP')}`);
  lines.push(`回答数: ${store.answers.length} 件`);
  lines.push('');
  lines.push('== 集計 ==');

  if (!store.survey.questions.length) {
    lines.push('設問がありません。');
  }

  for (const [index, q] of store.survey.questions.entries()) {
    lines.push('');
    lines.push(`${index + 1}. ${q.label}`);
    if (q.type === 'radio' || q.type === 'checkbox') {
      const agg = aggregates[q.id] || {};
      const totalVotes = Object.values(agg).reduce((sum, count) => sum + count, 0);
      for (const opt of q.options || []) {
        const count = agg[opt] || 0;
        const pct = totalVotes ? Math.round(count / totalVotes * 100) : 0;
        lines.push(`- ${opt}: ${count} 件 (${pct}%)`);
      }
    } else if (q.type === 'scale') {
      const agg = aggregates[q.id] || { avg: null, count: 0, distribution: {} };
      lines.push(`平均: ${agg.avg !== null ? agg.avg : '-'} / 5 (${agg.count} 件)`);
      for (const n of [1, 2, 3, 4, 5]) {
        lines.push(`- ${n}: ${(agg.distribution || {})[n] || 0} 件`);
      }
    } else if (q.type === 'text') {
      const texts = store.answers
        .map(answer => answer.responses[q.id])
        .filter(value => value && String(value).trim() !== '');
      if (!texts.length) {
        lines.push('- 回答なし');
      } else {
        texts.forEach((text, i) => lines.push(`- ${i + 1}: ${text}`));
      }
    }
  }

  lines.push('');
  lines.push('== 個別回答 ==');
  if (!store.answers.length) {
    lines.push('回答がありません。');
  }
  for (const answer of store.answers) {
    lines.push('');
    lines.push(`#${answer.id} ${new Date(answer.submittedAt).toLocaleString('ja-JP')}`);
    for (const q of store.survey.questions) {
      lines.push(`- ${q.label}: ${formatAnswerValue(answer.responses[q.id])}`);
    }
  }

  return `${lines.join('\n')}\n`;
}

// --- Survey routes ---

app.get('/api/survey', (req, res) => {
  res.json(store.survey);
});

app.put('/api/survey', (req, res) => {
  const error = validateSurveyPayload(req.body);
  if (error) return res.status(400).json({ error });
  store.survey = normalizeSurvey(req.body);
  saveStore();
  res.json(store.survey);
});

// --- Preset routes ---

app.get('/api/presets', (req, res) => {
  res.json({ presets: store.presets });
});

app.put('/api/presets/:slot', (req, res) => {
  const slot = Number(req.params.slot);
  if (!Number.isInteger(slot) || slot < 0 || slot >= 5) {
    return res.status(400).json({ error: 'Invalid preset slot' });
  }

  const survey = req.body.survey || {};
  const error = validateSurveyPayload(survey);
  if (error) return res.status(400).json({ error });

  const name = String(req.body.name || survey.title || `Preset ${slot + 1}`).trim().slice(0, 80);
  store.presets[slot] = {
    name,
    savedAt: new Date().toISOString(),
    survey: {
      ...normalizeSurvey(survey),
      isOpen: false,
    },
  };
  saveStore();
  res.json(store.presets[slot]);
});

app.delete('/api/presets/:slot', (req, res) => {
  const slot = Number(req.params.slot);
  if (!Number.isInteger(slot) || slot < 0 || slot >= 5) {
    return res.status(400).json({ error: 'Invalid preset slot' });
  }
  store.presets[slot] = null;
  saveStore();
  res.json({ ok: true });
});

// --- Answer routes ---

app.post('/api/answers', (req, res) => {
  if (!store.survey.isOpen) {
    return res.status(403).json({ error: 'Survey is closed' });
  }
  const { responses } = req.body;
  if (!responses || typeof responses !== 'object') {
    return res.status(400).json({ error: 'Invalid responses' });
  }
  if (store.answers.length >= 1000) {
    return res.status(409).json({ error: 'Answer limit reached' });
  }
  const normalizedResponses = {};
  for (const q of store.survey.questions) {
    const value = responses[q.id];
    if (q.type === 'checkbox') {
      normalizedResponses[q.id] = Array.isArray(value)
        ? value.map(v => String(v).slice(0, 500)).slice(0, 30)
        : [];
    } else {
      normalizedResponses[q.id] = value === undefined || value === null ? '' : String(value).slice(0, 2000);
    }
  }
  const entry = {
    id: store.nextAnswerId++,
    submittedAt: new Date().toISOString(),
    responses: normalizedResponses,
  };
  store.answers.push(entry);
  saveStore();
  res.status(201).json({ id: entry.id });
});

app.get('/api/answers', (req, res) => {
  res.json({ answers: store.answers, aggregates: getAggregates(), total: store.answers.length });
});

app.get('/api/answers/export.txt', (req, res) => {
  const stamp = new Date().toISOString().slice(0, 10);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="survey_results_${stamp}.txt"`);
  res.send(buildResultsText());
});

app.delete('/api/answers', (req, res) => {
  store.answers = [];
  store.nextAnswerId = 1;
  saveStore();
  res.json({ ok: true });
});

// Serve pages
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'survey.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`Survey server running on http://${HOST}:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin`);
  console.log(`Client: http://<your-ip>:${PORT}/`);
  console.log('Note: This tool has no authentication. Use it only on a trusted local network.');
});
