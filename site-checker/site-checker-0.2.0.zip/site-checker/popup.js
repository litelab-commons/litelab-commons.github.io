const pageUrl = document.querySelector("#pageUrl");
const riskSection = document.querySelector("#riskSection");
const riskLevel = document.querySelector("#riskLevel");
const riskList = document.querySelector("#riskList");
const ipv4List = document.querySelector("#ipv4List");
const ipv6List = document.querySelector("#ipv6List");
const externalCount = document.querySelector("#externalCount");
const externalList = document.querySelector("#externalList");
const mailCount = document.querySelector("#mailCount");
const mailList = document.querySelector("#mailList");
const domainName = document.querySelector("#domainName");
const domainAge = document.querySelector("#domainAge");
const whoisList = document.querySelector("#whoisList");
const refreshButton = document.querySelector("#refreshButton");
const saveHistoryButton = document.querySelector("#saveHistoryButton");
const openHistoryButton = document.querySelector("#openHistoryButton");
const openOptionsButton = document.querySelector("#openOptionsButton");
const whiteDomainButton = document.querySelector("#whiteDomainButton");
const whiteUrlButton = document.querySelector("#whiteUrlButton");
const alertDomainButton = document.querySelector("#alertDomainButton");
const alertUrlButton = document.querySelector("#alertUrlButton");
const fullscreenAllowUrlButton = document.querySelector("#fullscreenAllowUrlButton");
const statusText = document.querySelector("#status");
let latestScan = null;

const NEXT_PAGE_KEYWORDS = [
  "about", "about-us", "about_us", "contact", "company", "profile", "privacy",
  "legal", "law", "terms", "tokutei", "commerce", "guide", "support", "help",
  "main_page=about", "main_page=contact", "main_page=privacy", "main_page=conditions",
  "お問い合わせ", "お問合せ", "問合せ", "会社概要", "特定商取引", "特商法", "店舗情報"
];

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isIpAddress(hostname) {
  const ipv4 = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname);
  const ipv6 = hostname.includes(":");
  return ipv4 || ipv6;
}

function setIpList(list, values) {
  list.replaceChildren();

  if (!values.length) {
    const item = document.createElement("li");
    item.className = "empty";
    item.textContent = "なし";
    list.append(item);
    return;
  }

  for (const value of values) {
    const item = document.createElement("li");
    item.textContent = value;
    list.append(item);
  }
}

function setRiskRows(assessment) {
  riskList.replaceChildren();
  riskLevel.textContent = assessment.label;
  riskSection.classList.remove("is-low", "is-medium", "is-high");
  riskSection.classList.add(assessment.className);

  if (!assessment.items.length) {
    const item = document.createElement("li");
    item.className = "empty";
    item.textContent = "目立つシグナルはありません";
    riskList.append(item);
    return;
  }

  for (const signal of assessment.items) {
    const item = document.createElement("li");
    const title = document.createElement("span");
    const detail = document.createElement("span");
    title.className = "risk-title";
    detail.className = "risk-detail";
    title.textContent = signal.title;
    detail.textContent = signal.detail;
    item.append(title, detail);
    riskList.append(item);
  }
}

function summarizeAssessment(assessment) {
  return {
    riskLabel: assessment.label,
    riskScore: assessment.score || 0,
    signals: assessment.items.map((item) => item.title)
  };
}

function setExternalRows(rows) {
  externalList.replaceChildren();
  externalCount.textContent = rows.length ? `${rows.length}ドメイン` : "なし";

  if (!rows.length) {
    const item = document.createElement("li");
    item.className = "empty";
    item.textContent = "なし";
    externalList.append(item);
    return;
  }

  for (const row of rows.slice(0, 20)) {
    const item = document.createElement("li");
    const domain = document.createElement("span");
    const meta = document.createElement("span");
    domain.className = "external-domain";
    meta.className = "external-meta";
    domain.textContent = row.hostname;
    meta.textContent = `${row.count}件 / ${row.types.join(", ")}`;
    item.append(domain, meta);
    externalList.append(item);
  }
}

function setMailRows(rows) {
  mailList.replaceChildren();
  mailCount.textContent = rows.length ? `${rows.length}ドメイン` : "なし";

  if (!rows.length) {
    const item = document.createElement("li");
    item.className = "empty";
    item.textContent = "なし";
    mailList.append(item);
    return;
  }

  for (const row of rows.slice(0, 20)) {
    const item = document.createElement("li");
    const domain = document.createElement("span");
    const meta = document.createElement("span");
    const source = document.createElement("span");
    domain.className = "mail-domain";
    meta.className = "mail-meta";
    source.className = "mail-meta";
    domain.textContent = row.domain;
    meta.textContent = `${row.count}件 / ${row.samples.join(", ")}`;
    source.textContent = row.sources?.length ? `取得元: ${row.sources.join(", ")}` : "";
    item.append(domain, meta, source);
    mailList.append(item);
  }
}

function mergeMailDomainRows(...groups) {
  const merged = new Map();

  for (const rows of groups) {
    for (const row of rows || []) {
      const entry = merged.get(row.domain) || {
        domain: row.domain,
        count: 0,
        samples: new Set(),
        sources: new Set()
      };
      entry.count += row.count;
      row.samples?.forEach((sample) => entry.samples.add(sample));
      row.sources?.forEach((source) => entry.sources.add(source));
      merged.set(row.domain, entry);
    }
  }

  return [...merged.values()]
    .map((entry) => ({
      domain: entry.domain,
      count: entry.count,
      samples: [...entry.samples].sort().slice(0, 3),
      sources: [...entry.sources].sort().slice(0, 3)
    }))
    .sort((a, b) => b.count - a.count || a.domain.localeCompare(b.domain));
}

function getShannonEntropy(value) {
  const counts = [...value].reduce((map, char) => {
    map.set(char, (map.get(char) || 0) + 1);
    return map;
  }, new Map());
  return [...counts.values()].reduce((entropy, count) => {
    const p = count / value.length;
    return entropy - p * Math.log2(p);
  }, 0);
}

function isLowPatternLabel(label) {
  if (label.length < 4 || label.length > 16 || /[^a-z0-9-]/.test(label)) {
    return false;
  }

  const compact = label.replace(/-/g, "");
  const consonants = compact.replace(/[aeiou0-9]/g, "").length;
  const consonantRatio = consonants / Math.max(compact.length, 1);
  const entropy = getShannonEntropy(compact);
  return consonantRatio >= 0.72 || entropy >= 3.25;
}

function getLowPatternUrlParts(url) {
  const parsed = new URL(url);
  const cleanHost = parsed.hostname.replace(/\.$/, "").toLowerCase();
  const domain = getRegistrableDomain(cleanHost);
  const hostParts = cleanHost.split(".").filter(Boolean);
  const domainParts = domain.split(".");
  const domainLabel = domainParts.at(-2) || "";
  const subdomains = hostParts.slice(0, Math.max(0, hostParts.length - domainParts.length));
  const pathParts = parsed.pathname.split("/").filter(Boolean);
  return [...subdomains, domainLabel, ...pathParts].filter(isLowPatternLabel);
}

function includesAnyNeedle(value, needles) {
  return needles.some((needle) => value.includes(needle));
}

function assessDomainRisk(targetUrl, settings, domainAgeDays = null, mailDomains = []) {
  const items = [];
  const parsed = new URL(targetUrl);
  const hostname = parsed.hostname;
  const cleanHost = hostname.replace(/\.$/, "").toLowerCase();
  const domain = getRegistrableDomain(cleanHost);
  const hostParts = cleanHost.split(".").filter(Boolean);
  const domainParts = domain.split(".");
  const tld = domainParts.at(-1) || "";
  const domainLabel = domainParts.at(-2) || "";
  const subdomains = hostParts.slice(0, Math.max(0, hostParts.length - domainParts.length));
  const labels = [...subdomains, domainLabel].filter(Boolean);
  const joinedLabels = labels.join(".");
  const whiteTlds = new Set(settings.whiteTlds);
  const watchTlds = new Set(settings.watchTlds);
  const trustedBrandDomains = new Set(settings.trustedBrandDomains);
  const freeMailDomains = new Set(settings.freeMailDomains);
  const isTrustedBrandDomain = trustedBrandDomains.has(domain);

  if (GP_isWhiteListedUrl(parsed.href, settings)) {
    return {
      label: "信頼済み",
      className: "is-low",
      score: 0,
      items: [{
        weight: 0,
        title: "信頼リスト登録済み",
        detail: "このURLまたはドメインは設定上の信頼リストに含まれています。"
      }]
    };
  }

  const alertMatches = GP_getAlertListMatches(parsed.href, settings);
  if (alertMatches.url) {
    items.push({
      weight: 4,
      title: "要確認URL",
      detail: "設定上の要確認URLに完全一致しています。"
    });
  }

  if (alertMatches.domain) {
    items.push({
      weight: 4,
      title: "要確認ドメイン",
      detail: "設定上の要確認ドメインまたはそのサブドメインに一致しています。"
    });
  }

  if (alertMatches.tld) {
    items.push({
      weight: 3,
      title: `要確認TLD .${alertMatches.tld}`,
      detail: "設定上の要確認TLDに含まれています。"
    });
  }

  if (settings.autoWarnUntrustedDomain && !GP_isHostInDomainList(cleanHost, settings.whiteDomains)) {
    items.push({
      weight: 4,
      title: "ホワイトリスト外",
      detail: "信頼ドメインに登録されていないため、自動警告の対象です。"
    });
  }

  if (tld && !whiteTlds.has(tld)) {
    items.push({
      weight: 1,
      title: `信頼TLD外 .${tld}`,
      detail: "設定上の信頼TLDに含まれていません。"
    });
  }

  if (watchTlds.has(tld)) {
    items.push({
      weight: 2,
      title: `ウォッチTLD .${tld}`,
      detail: "設定上のウォッチTLDに含まれています。"
    });
  }

  for (const label of subdomains) {
    if (isLowPatternLabel(label)) {
      items.push({
        weight: 2,
        title: `規則性の少ないサブドメイン: ${label}`,
        detail: "短い英数字の不自然なサブドメインは量産サイトで見かけることがあります。"
      });
      break;
    }
  }

  if (isLowPatternLabel(domainLabel)) {
    items.push({
      weight: 2,
      title: `規則性の少ないドメイン名: ${domainLabel}`,
      detail: "登録ドメイン本体が機械的な文字列に近い形です。"
    });
  }

  if (watchTlds.has(tld) && includesAnyNeedle(joinedLabels, settings.commerceBaitWords)) {
    items.push({
      weight: 2,
      title: "購買誘導語 + 要確認TLD",
      detail: "pay/buy/sale/resell などの語と短期利用されやすいTLDが組み合わさっています。"
    });
  }

  if (settings.detailBrandSignal && !isTrustedBrandDomain && includesAnyNeedle(joinedLabels, settings.brandBaitWords)) {
    items.push({
      weight: 3,
      title: "ブランド・金融系に見える語",
      detail: "正規ブランド名や金融系に見える語を含みます。URLの真正性確認が必要です。"
    });
  }

  if (cleanHost.includes("xn--")) {
    items.push({
      weight: 3,
      title: "Punycodeドメイン",
      detail: "見た目が似た別文字ドメインの可能性があります。"
    });
  }

  if (settings.detailLowPatternUrlSignal) {
    const lowPatternParts = getLowPatternUrlParts(parsed.href);
    if (lowPatternParts.length >= settings.lowPatternUrlMinCount) {
      items.push({
        weight: 2,
        title: `規則性の少ないURL構造 (${lowPatternParts.length}件)`,
        detail: lowPatternParts.slice(0, 5).join(", ")
      });
    }
  }

  if (settings.detailDomainAgeSignal && domainAgeDays !== null && domainAgeDays < settings.ageNewDays) {
    items.push({
      weight: 3,
      title: `作成から${settings.ageNewDays}日未満`,
      detail: `RDAP上の作成から${domainAgeDays}日です。`
    });
  } else if (settings.detailDomainAgeSignal && domainAgeDays !== null && domainAgeDays < settings.ageYoungDays) {
    items.push({
      weight: 2,
      title: `作成から${settings.ageYoungDays}日未満`,
      detail: `RDAP上の作成から${domainAgeDays}日です。`
    });
  } else if (settings.detailDomainAgeSignal && domainAgeDays !== null && domainAgeDays < settings.ageOneYearDays) {
    items.push({
      weight: 1,
      title: `作成から${settings.ageOneYearDays}日未満`,
      detail: `RDAP上の作成から${domainAgeDays}日です。`
    });
  }

  if (cleanHost.length >= 42) {
    items.push({
      weight: 1,
      title: "長いホスト名",
      detail: "長いホスト名は偽装や量産パターンで使われることがあります。"
    });
  }

  const registrableDomain = getRegistrableDomain(cleanHost);
  const freeMailMatches = mailDomains.filter((row) => freeMailDomains.has(row.domain));
  const lowPatternMailMatches = mailDomains.filter((row) => {
    const label = row.domain.split(".").at(0) || "";
    return isLowPatternLabel(label);
  });

  if (settings.detailMailSignal && mailDomains.length) {
    items.push({
      weight: 1,
      title: "ページ内メールが別ドメイン",
      detail: `${registrableDomain} と異なるメールドメインが ${mailDomains.length} 件あります。`
    });
  }

  if (settings.detailMailSignal && freeMailMatches.length) {
    items.push({
      weight: 2,
      title: "問い合わせ先がフリーメール",
      detail: freeMailMatches.map((row) => row.domain).slice(0, 3).join(", ")
    });
  }

  if (settings.detailMailSignal && lowPatternMailMatches.length) {
    items.push({
      weight: 2,
      title: "規則性の少ないメールドメイン",
      detail: lowPatternMailMatches.map((row) => row.domain).slice(0, 3).join(", ")
    });
  }

  const score = items.reduce((sum, item) => sum + item.weight, 0);
  const level = score >= 5
    ? { label: "強め", className: "is-high" }
    : score >= 2
      ? { label: "要確認", className: "is-medium" }
      : { label: "低め", className: "is-low" };

  return {
    ...level,
    score,
    items: items.sort((a, b) => b.weight - a.weight)
  };
}

function setWhoisRows(rows) {
  whoisList.replaceChildren();

  for (const [label, value] of rows) {
    const row = document.createElement("div");
    const term = document.createElement("dt");
    const description = document.createElement("dd");
    term.textContent = label;
    description.textContent = value || "不明";
    row.append(term, description);
    whoisList.append(row);
  }
}

function setDomainAge(state, text) {
  domainAge.className = `domain-age ${state}`;
  domainAge.replaceChildren();

  const label = document.createElement("span");
  const value = document.createElement("strong");
  label.textContent = "ドメイン年齢";
  value.textContent = text;
  domainAge.append(label, value);
}

function formatDate(value) {
  if (!value) {
    return "";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return date.toLocaleDateString("ja-JP", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
}

function getDomainAge(createdAt) {
  if (!createdAt) {
    return null;
  }

  const createdDate = new Date(createdAt);
  if (Number.isNaN(createdDate.getTime())) {
    return null;
  }

  const now = new Date();
  const days = Math.max(0, Math.floor((now.getTime() - createdDate.getTime()) / 86400000));
  const years = Math.floor(days / 365);
  const months = Math.floor((days % 365) / 30);
  let state = "is-established";

  if (days < 30) {
    state = "is-new";
  } else if (days < 180) {
    state = "is-young";
  }

  const relative = years > 0
    ? `約${years}年${months}か月`
    : months > 0
      ? `約${months}か月`
      : `${days}日`;

  return {
    days,
    state,
    text: `${days.toLocaleString("ja-JP")}日（${relative}）`
  };
}

function getDomainAgeDaysFromRdapResult(result) {
  if (result.status !== "fulfilled" || typeof result.value !== "object") {
    return null;
  }

  return Number.isInteger(result.value.domainAgeDays) ? result.value.domainAgeDays : null;
}

async function queryDns(hostname, type) {
  const params = new URLSearchParams({ name: hostname, type });
  const response = await fetch(`https://dns.google/resolve?${params.toString()}`, {
    headers: { accept: "application/dns-json" }
  });

  if (!response.ok) {
    throw new Error(`DNS lookup failed: ${response.status}`);
  }

  const data = await response.json();
  const recordType = type === "A" ? 1 : 28;
  return (data.Answer || [])
    .filter((answer) => answer.type === recordType && typeof answer.data === "string")
    .map((answer) => answer.data);
}

function getRegistrableDomain(hostname) {
  const cleanHost = hostname.replace(/\.$/, "").toLowerCase();
  if (isIpAddress(cleanHost) || cleanHost === "localhost") {
    return cleanHost;
  }

  const parts = cleanHost.split(".").filter(Boolean);
  if (parts.length <= 2) {
    return cleanHost;
  }

  const secondLevelTlds = new Set([
    "ac.jp", "ad.jp", "co.jp", "ed.jp", "go.jp", "gr.jp", "lg.jp", "ne.jp", "or.jp",
    "co.uk", "org.uk", "ac.uk", "gov.uk",
    "com.au", "net.au", "org.au",
    "com.cn", "net.cn", "org.cn", "gov.cn",
    "com.tw", "net.tw", "org.tw",
    "com.hk", "net.hk", "org.hk",
    "co.kr", "or.kr", "go.kr"
  ]);
  const lastTwo = parts.slice(-2).join(".");

  if (secondLevelTlds.has(lastTwo) && parts.length >= 3) {
    return parts.slice(-3).join(".");
  }

  return parts.slice(-2).join(".");
}

async function lookupIpAddresses(hostname) {
  setIpList(ipv4List, []);
  setIpList(ipv6List, []);

  if (isIpAddress(hostname)) {
    setIpList(hostname.includes(":") ? ipv6List : ipv4List, [hostname]);
    return {
      status: "IP直指定",
      addresses: [hostname]
    };
  }

  const [ipv4, ipv6] = await Promise.all([
    queryDns(hostname, "A"),
    queryDns(hostname, "AAAA")
  ]);

  setIpList(ipv4List, [...new Set(ipv4)]);
  setIpList(ipv6List, [...new Set(ipv6)]);
  const addresses = [...new Set([...ipv4, ...ipv6])];
  return {
    status: addresses.length ? "IP取得済み" : "公開DNSではIPなし",
    addresses
  };
}

function getRdapEventDate(events, action) {
  return events?.find((event) => event.eventAction === action)?.eventDate || "";
}

function getRdapRegistrar(entities) {
  const registrar = entities?.find((entity) => entity.roles?.includes("registrar"));
  const vcard = registrar?.vcardArray?.[1] || [];
  const fn = vcard.find((entry) => entry[0] === "fn");
  return fn?.[3] || registrar?.handle || "";
}

async function lookupRdap(url, settings) {
  const hostname = url.hostname;
  const domain = getRegistrableDomain(hostname);
  domainName.textContent = domain;

  if (isIpAddress(domain) || domain === "localhost") {
    setDomainAge("is-unknown", "対象外");
    setWhoisRows([["対象", "ドメインではありません"]]);
    return {
      status: "WHOIS対象外",
      domainAgeDays: null
    };
  }

  const response = await fetch(`https://rdap.org/domain/${encodeURIComponent(domain)}`, {
    headers: { accept: "application/rdap+json, application/json" }
  });

  if (!response.ok) {
    throw new Error(`RDAP lookup failed: ${response.status}`);
  }

  const data = await response.json();
  const createdAt = getRdapEventDate(data.events, "registration");
  const registrar = getRdapRegistrar(data.entities);
  const updatedAt = getRdapEventDate(data.events, "last changed");
  const expiresAt = getRdapEventDate(data.events, "expiration");
  const domainAgeResult = getDomainAge(createdAt);

  if (domainAgeResult) {
    setDomainAge(domainAgeResult.state, domainAgeResult.text);
    setRiskRows(assessDomainRisk(url.href, settings, domainAgeResult.days));
  } else {
    setDomainAge("is-unknown", "作成日不明");
    setRiskRows(assessDomainRisk(url.href, settings));
  }

  setWhoisRows([
    ["Domain", data.ldhName || domain],
    ["Registrar", registrar],
    ["Age Days", domainAgeResult ? domainAgeResult.days.toLocaleString("ja-JP") : ""],
    ["Created", formatDate(createdAt)],
    ["Updated", formatDate(updatedAt)],
    ["Expires", formatDate(expiresAt)],
    ["Status", (data.status || []).slice(0, 3).join(", ")]
  ]);

  return {
    status: "RDAP取得済み",
    domain: data.ldhName || domain,
    registrar,
    createdAt,
    updatedAt,
    expiresAt,
    domainAgeDays: domainAgeResult ? domainAgeResult.days : null
  };
}

function collectPageDomains() {
  const externalResources = new Map();
  const mailDomains = new Map();
  const nextPageLinks = [];
  const nextPageKeywords = [
    "about", "about-us", "about_us", "contact", "company", "profile", "privacy",
    "legal", "law", "terms", "tokutei", "commerce", "guide", "support", "help",
    "main_page=about", "main_page=contact", "main_page=privacy", "main_page=conditions",
    "お問い合わせ", "お問合せ", "問合せ", "会社概要", "特定商取引", "特商法", "店舗情報"
  ];

  const isIp = (hostname) => /^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname) || hostname.includes(":");
  const getDomain = (hostname) => {
    const cleanHost = hostname.replace(/\.$/, "").toLowerCase();
    if (isIp(cleanHost) || cleanHost === "localhost") {
      return cleanHost;
    }

    const parts = cleanHost.split(".").filter(Boolean);
    if (parts.length <= 2) {
      return cleanHost;
    }

    const secondLevelTlds = new Set([
      "ac.jp", "ad.jp", "co.jp", "ed.jp", "go.jp", "gr.jp", "lg.jp", "ne.jp", "or.jp",
      "co.uk", "org.uk", "ac.uk", "gov.uk",
      "com.au", "net.au", "org.au",
      "com.cn", "net.cn", "org.cn", "gov.cn",
      "com.tw", "net.tw", "org.tw",
      "com.hk", "net.hk", "org.hk",
      "co.kr", "or.kr", "go.kr"
    ]);
    const lastTwo = parts.slice(-2).join(".");

    if (secondLevelTlds.has(lastTwo) && parts.length >= 3) {
      return parts.slice(-3).join(".");
    }

    return parts.slice(-2).join(".");
  };

  const extractEmails = (text) => {
    const normalized = (text || "")
      .normalize("NFKC")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/\s*@\s*/g, "@")
      .replace(/\s*\.\s*/g, ".");
    return normalized.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
  };
  const decodeCloudflareEmail = (encoded) => {
    const clean = (encoded || "").trim();
    if (!/^[a-f0-9]+$/i.test(clean) || clean.length < 4 || clean.length % 2 !== 0) {
      return "";
    }

    const key = parseInt(clean.slice(0, 2), 16);
    let email = "";
    for (let index = 2; index < clean.length; index += 2) {
      email += String.fromCharCode(parseInt(clean.slice(index, index + 2), 16) ^ key);
    }
    return email;
  };

  const addExternalResource = (rawUrl, type) => {
    if (!rawUrl || rawUrl.startsWith("data:") || rawUrl.startsWith("blob:")) {
      return;
    }

    try {
      const parsed = new URL(rawUrl, location.href);
      if (!["http:", "https:"].includes(parsed.protocol) || parsed.hostname === location.hostname) {
        return;
      }

      const entry = externalResources.get(parsed.hostname) || {
        hostname: parsed.hostname,
        count: 0,
        types: new Set()
      };
      entry.count += 1;
      entry.types.add(type);
      externalResources.set(parsed.hostname, entry);
    } catch {
      // Ignore malformed URLs found in attributes.
    }
  };

  const addSrcsetResources = (srcset, type) => {
    for (const candidate of (srcset || "").split(",")) {
      addExternalResource(candidate.trim().split(/\s+/)[0], type);
    }
  };

  const addEmail = (email, source = location.href) => {
    const normalized = email.trim().toLowerCase().replace(/^mailto:/, "").split(/[?#]/)[0];
    const domain = normalized.split("@").at(-1);
    if (!domain || !domain.includes(".")) {
      return;
    }

    const currentDomain = location.hostname.replace(/\.$/, "").toLowerCase();
    if (getDomain(domain) === getDomain(currentDomain)) {
      return;
    }

    const entry = mailDomains.get(domain) || {
      domain,
      count: 0,
      samples: new Set(),
      sources: new Set()
    };
    entry.count += 1;
    entry.samples.add(normalized);
    entry.sources.add(source);
    mailDomains.set(domain, entry);
  };

  const addNextPageLink = (rawUrl, text = "") => {
    try {
      const parsed = new URL(rawUrl, location.href);
      const currentDomain = getDomain(location.hostname);
      if (!["http:", "https:"].includes(parsed.protocol) || getDomain(parsed.hostname) !== currentDomain) {
        return;
      }

      const haystack = `${parsed.pathname} ${parsed.search} ${text}`.toLowerCase();
      if (!nextPageKeywords.some((keyword) => haystack.includes(keyword))) {
        return;
      }

      const href = parsed.href.split("#")[0];
      if (href !== location.href.split("#")[0] && !nextPageLinks.includes(href)) {
        nextPageLinks.push(href);
      }
    } catch {
      // Ignore malformed links.
    }
  };

  document.querySelectorAll("img").forEach((element) => {
    addExternalResource(element.currentSrc || element.src, "image");
    addSrcsetResources(element.srcset, "image");
  });
  document.querySelectorAll("script[src]").forEach((element) => addExternalResource(element.src, "script"));
  document.querySelectorAll("iframe[src], frame[src]").forEach((element) => addExternalResource(element.src, "frame"));
  document.querySelectorAll("link[href]").forEach((element) => addExternalResource(element.href, element.rel || "link"));
  document.querySelectorAll("video[src], audio[src], source[src], track[src]").forEach((element) => addExternalResource(element.src, "media"));
  document.querySelectorAll("embed[src], object[data]").forEach((element) => addExternalResource(element.src || element.data, "embed"));
  document.querySelectorAll("a[href]").forEach((element) => {
    addExternalResource(element.href, "link-url");
    addNextPageLink(element.href, element.innerText || element.textContent || "");
  });
  document.querySelectorAll("a[href^='mailto:']").forEach((element) => addEmail(element.href));
  document.querySelectorAll("[data-cfemail]").forEach((element) => {
    const decoded = decodeCloudflareEmail(element.getAttribute("data-cfemail"));
    if (decoded) {
      addEmail(decoded);
    }
  });
  document.querySelectorAll("a[href*='/cdn-cgi/l/email-protection#']").forEach((element) => {
    const encoded = element.href.split("#").at(-1);
    const decoded = decodeCloudflareEmail(encoded);
    if (decoded) {
      addEmail(decoded);
    }
  });

  const text = document.body?.innerText || "";
  const emailMatches = extractEmails(text);
  emailMatches.forEach(addEmail);

  return {
    externalResources: [...externalResources.values()]
      .map((entry) => ({
        hostname: entry.hostname,
        count: entry.count,
        types: [...entry.types].sort()
      }))
      .sort((a, b) => b.count - a.count || a.hostname.localeCompare(b.hostname))
      .slice(0, 50),
    mailDomains: [...mailDomains.values()]
      .map((entry) => ({
        domain: entry.domain,
        count: entry.count,
        samples: [...entry.samples].sort().slice(0, 3),
        sources: [...entry.sources].sort().slice(0, 3)
      }))
      .sort((a, b) => b.count - a.count || a.domain.localeCompare(b.domain))
      .slice(0, 50),
    nextPageLinks: nextPageLinks.slice(0, 5),
    url: location.href
  };
}

function extractMailDomainsFromHtml(html, pageUrl, currentHostname) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const rows = new Map();
  const extractEmails = (text) => {
    const normalized = (text || "")
      .normalize("NFKC")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/\s*@\s*/g, "@")
      .replace(/\s*\.\s*/g, ".");
    return normalized.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
  };
  const decodeCloudflareEmail = (encoded) => {
    const clean = (encoded || "").trim();
    if (!/^[a-f0-9]+$/i.test(clean) || clean.length < 4 || clean.length % 2 !== 0) {
      return "";
    }

    const key = parseInt(clean.slice(0, 2), 16);
    let email = "";
    for (let index = 2; index < clean.length; index += 2) {
      email += String.fromCharCode(parseInt(clean.slice(index, index + 2), 16) ^ key);
    }
    return email;
  };

  const addEmail = (email) => {
    const normalized = email.trim().toLowerCase().replace(/^mailto:/, "").split(/[?#]/)[0];
    const domain = normalized.split("@").at(-1);
    if (!domain || !domain.includes(".")) {
      return;
    }

    if (getRegistrableDomain(domain) === getRegistrableDomain(currentHostname)) {
      return;
    }

    const entry = rows.get(domain) || {
      domain,
      count: 0,
      samples: new Set(),
      sources: new Set()
    };
    entry.count += 1;
    entry.samples.add(normalized);
    entry.sources.add(pageUrl);
    rows.set(domain, entry);
  };

  doc.querySelectorAll("a[href^='mailto:']").forEach((element) => addEmail(element.getAttribute("href") || ""));
  doc.querySelectorAll("[data-cfemail]").forEach((element) => {
    const decoded = decodeCloudflareEmail(element.getAttribute("data-cfemail"));
    if (decoded) {
      addEmail(decoded);
    }
  });
  doc.querySelectorAll("a[href*='/cdn-cgi/l/email-protection#']").forEach((element) => {
    const encoded = (element.getAttribute("href") || "").split("#").at(-1);
    const decoded = decodeCloudflareEmail(encoded);
    if (decoded) {
      addEmail(decoded);
    }
  });
  const text = doc.body?.innerText || doc.documentElement?.textContent || "";
  const emailMatches = extractEmails(text);
  emailMatches.forEach(addEmail);

  return [...rows.values()].map((entry) => ({
    domain: entry.domain,
    count: entry.count,
    samples: [...entry.samples].sort().slice(0, 3),
    sources: [...entry.sources].sort().slice(0, 3)
  }));
}

async function lookupLinkedPageMailDomains(urls, currentHostname) {
  const results = await Promise.allSettled(urls.map(async (url) => {
    const response = await fetch(url, {
      credentials: "omit",
      redirect: "follow"
    });
    const contentType = response.headers.get("content-type") || "";

    if (!response.ok || !contentType.includes("text/html")) {
      return [];
    }

    const html = await response.text();
    return extractMailDomainsFromHtml(html, url, currentHostname);
  }));

  return results.flatMap((result) => result.status === "fulfilled" ? result.value : []);
}

async function inspectCurrentPage() {
  refreshButton.disabled = true;
  saveHistoryButton.disabled = true;
  latestScan = null;
  statusText.textContent = "ページ情報を取得しています。";
  pageUrl.textContent = "Checking current tab...";
  setRiskRows({ label: "確認中", className: "is-low", items: [] });
  externalCount.textContent = "確認中";
  setExternalRows([]);
  mailCount.textContent = "確認中";
  setMailRows([]);
  domainName.textContent = "確認中";
  setDomainAge("is-loading", "確認中");
  setWhoisRows([["Status", "確認中"]]);
  setIpList(ipv4List, []);
  setIpList(ipv6List, []);

  try {
    const tab = await getActiveTab();
    const url = tab?.url ? new URL(tab.url) : null;

    if (!url || !["http:", "https:"].includes(url.protocol) || !url.hostname) {
      pageUrl.textContent = "対象外のページ";
      statusText.textContent = "通常のWebページを開いてから実行してください。";
      return;
    }

    pageUrl.textContent = url.href;
    const settings = await GP_getSettings();
    let assessment = assessDomainRisk(url.href, settings);
    setRiskRows(assessment);
    const [ipResult, rdapResult, externalResult] = await Promise.allSettled([
      lookupIpAddresses(url.hostname),
      lookupRdap(url, settings),
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: collectPageDomains
      })
    ]);

    if (ipResult.status === "rejected") {
      setIpList(ipv4List, []);
      setIpList(ipv6List, []);
    }

    if (rdapResult.status === "rejected") {
      setDomainAge("is-unknown", "取得不可");
      setWhoisRows([["Status", "RDAPで取得できませんでした"]]);
    }

    if (externalResult.status === "fulfilled") {
      const pageDomains = externalResult.value[0].result;
      const linkedPageMailDomains = await lookupLinkedPageMailDomains(pageDomains.nextPageLinks || [], url.hostname)
        .catch(() => []);
      const mailDomains = mergeMailDomainRows(pageDomains.mailDomains || [], linkedPageMailDomains);
      setExternalRows(pageDomains.externalResources || []);
      setMailRows(mailDomains);
      assessment = assessDomainRisk(
        url.href,
        settings,
        getDomainAgeDaysFromRdapResult(rdapResult),
        mailDomains
      );
      setRiskRows(assessment);
    } else {
      setExternalRows([]);
      setMailRows([]);
    }

    const ipValue = ipResult.status === "fulfilled" ? ipResult.value : { addresses: [] };
    const pageDomains = externalResult.status === "fulfilled" ? externalResult.value[0].result : {};
    const mailDomains = mailList.querySelector(".empty") ? [] : [...mailList.querySelectorAll(".mail-domain")].map((element) => element.textContent);
    const rdapValue = rdapResult.status === "fulfilled" ? rdapResult.value : {};
    latestScan = {
      checkedAt: new Date().toISOString(),
      url: url.href,
      hostname: url.hostname,
      registrableDomain: getRegistrableDomain(url.hostname),
      ...summarizeAssessment(assessment),
      ipv4: [...ipv4List.querySelectorAll("li:not(.empty)")].map((item) => item.textContent),
      ipv6: [...ipv6List.querySelectorAll("li:not(.empty)")].map((item) => item.textContent),
      ipAddresses: ipValue.addresses || [],
      domainAgeDays: rdapValue.domainAgeDays ?? null,
      registrar: rdapValue.registrar || "",
      rdapDomain: rdapValue.domain || "",
      mailDomains,
      externalDomains: (pageDomains.externalResources || []).map((row) => row.hostname).slice(0, 50)
    };
    saveHistoryButton.disabled = false;

    const statuses = [ipResult, rdapResult, externalResult]
      .map((result) => result.status === "fulfilled" ? "OK" : "NG");
    statusText.textContent = `判定しました。IP:${statuses[0]} RDAP:${statuses[1]} 外部:${statuses[2]}`;
  } catch (error) {
    if (pageUrl.textContent === "Checking current tab...") {
      pageUrl.textContent = "取得エラー";
    }
    statusText.textContent = "このページでは一部または全部を取得できない可能性があります。";
    console.error(error);
  } finally {
    refreshButton.disabled = false;
  }
}

async function addCurrentDomainToWhiteList() {
  const tab = await getActiveTab();
  const url = tab?.url ? new URL(tab.url) : null;
  if (!url || !["http:", "https:"].includes(url.protocol)) {
    statusText.textContent = "通常のWebページで実行してください。";
    return;
  }

  const settings = await GP_getSettings();
  const domain = getRegistrableDomain(url.hostname);
  const whiteDomains = [...new Set([...settings.whiteDomains, domain])].sort();
  await GP_saveSettings({ ...settings, whiteDomains });
  statusText.textContent = `${domain} を信頼ドメインに登録しました。`;
  inspectCurrentPage();
}

async function addCurrentUrlToWhiteList() {
  const tab = await getActiveTab();
  const url = tab?.url ? new URL(tab.url) : null;
  if (!url || !["http:", "https:"].includes(url.protocol)) {
    statusText.textContent = "通常のWebページで実行してください。";
    return;
  }

  const editedUrl = prompt("信頼登録するURLを編集できます。", url.href);
  if (editedUrl === null) {
    statusText.textContent = "信頼URL登録をキャンセルしました。";
    return;
  }

  const normalizedUrl = GP_normalizeUrl(editedUrl);
  if (!normalizedUrl) {
    statusText.textContent = "信頼URLとして登録できるURLではありません。";
    return;
  }

  const settings = await GP_getSettings();
  const whiteUrls = [...new Set([...settings.whiteUrls, normalizedUrl])].sort();
  await GP_saveSettings({ ...settings, whiteUrls });
  statusText.textContent = "編集したURLを信頼URLに登録しました。";
  inspectCurrentPage();
}

async function addCurrentDomainToAlertList() {
  const tab = await getActiveTab();
  const url = tab?.url ? new URL(tab.url) : null;
  if (!url || !["http:", "https:"].includes(url.protocol)) {
    statusText.textContent = "通常のWebページで実行してください。";
    return;
  }

  const settings = await GP_getSettings();
  const domain = getRegistrableDomain(url.hostname);
  const alertDomains = [...new Set([...settings.alertDomains, domain])].sort();
  await GP_saveSettings({ ...settings, alertDomains });
  statusText.textContent = `${domain} を要確認ドメインに登録しました。`;
  inspectCurrentPage();
}

async function addCurrentUrlToAlertList() {
  const tab = await getActiveTab();
  const url = tab?.url ? new URL(tab.url) : null;
  if (!url || !["http:", "https:"].includes(url.protocol)) {
    statusText.textContent = "通常のWebページで実行してください。";
    return;
  }

  const editedUrl = prompt("要確認登録するURLを編集できます。", url.href);
  if (editedUrl === null) {
    statusText.textContent = "要確認URL登録をキャンセルしました。";
    return;
  }

  const normalizedUrl = GP_normalizeUrl(editedUrl);
  if (!normalizedUrl) {
    statusText.textContent = "要確認URLとして登録できるURLではありません。";
    return;
  }

  const settings = await GP_getSettings();
  const alertUrls = [...new Set([...settings.alertUrls, normalizedUrl])].sort();
  await GP_saveSettings({ ...settings, alertUrls });
  statusText.textContent = "編集したURLを要確認URLに登録しました。";
  inspectCurrentPage();
}

async function addCurrentUrlToFullscreenAllowList() {
  const tab = await getActiveTab();
  const url = tab?.url ? new URL(tab.url) : null;
  if (!url || !["http:", "https:"].includes(url.protocol)) {
    statusText.textContent = "通常のWebページで実行してください。";
    return;
  }

  const editedUrl = prompt("フルスクリーンを許可するURLパスを編集できます。", `${url.origin}${url.pathname}`);
  if (editedUrl === null) {
    statusText.textContent = "フルスクリーン許可URL登録をキャンセルしました。";
    return;
  }

  const normalizedUrl = GP_normalizeUrl(editedUrl);
  if (!normalizedUrl) {
    statusText.textContent = "フルスクリーン許可URLとして登録できるURLではありません。";
    return;
  }

  const settings = await GP_getSettings();
  const fullscreenAllowUrls = [...new Set([...settings.fullscreenAllowUrls, normalizedUrl])].sort();
  await GP_saveSettings({ ...settings, fullscreenAllowUrls });
  statusText.textContent = "編集したURLをフルスクリーン許可URLに登録しました。";
}

async function saveCurrentHistory() {
  if (!latestScan) {
    statusText.textContent = "保存できる判定結果がまだありません。";
    return;
  }

  await GP_saveHistoryEntry(latestScan);
  statusText.textContent = "判定履歴に保存しました。";
}

async function openOptionsPage() {
  try {
    await chrome.runtime.openOptionsPage();
  } catch {
    await chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
  }
}

refreshButton.addEventListener("click", inspectCurrentPage);
saveHistoryButton.addEventListener("click", saveCurrentHistory);
openHistoryButton.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("history.html") }));
openOptionsButton.addEventListener("click", openOptionsPage);
whiteDomainButton.addEventListener("click", addCurrentDomainToWhiteList);
whiteUrlButton.addEventListener("click", addCurrentUrlToWhiteList);
alertDomainButton.addEventListener("click", addCurrentDomainToAlertList);
alertUrlButton.addEventListener("click", addCurrentUrlToAlertList);
fullscreenAllowUrlButton.addEventListener("click", addCurrentUrlToFullscreenAllowList);
inspectCurrentPage();
