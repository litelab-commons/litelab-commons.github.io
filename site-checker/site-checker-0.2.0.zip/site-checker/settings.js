const GP_DEFAULT_SETTINGS = {
  autoWarningEnabled: true,
  autoWarnUntrustedDomain: false,
  detailBrandSignal: true,
  detailDomainAgeSignal: true,
  detailMailSignal: true,
  detailLowPatternUrlSignal: true,
  lowPatternUrlMinCount: 2,
  whiteDomains: [],
  whiteUrls: [],
  whiteTlds: ["jp", "co.jp", "com", "net", "org", "ac.jp", "go.jp", "or.jp", "ne.jp"],
  alertDomains: [],
  alertUrls: [],
  alertTlds: [],
  fullscreenAllowUrls: [],
  watchTlds: [
    "shop", "top", "xyz", "click", "monster", "quest", "cam", "cyou", "buzz", "icu",
    "vip", "work", "homes", "store", "online", "site", "fun", "live", "rest", "sbs",
    "sale", "world", "best", "fit", "lol", "club", "my", "beer", "qpon", "today",
    "guru", "surf"
  ],
  commerceBaitWords: [
    "pay", "buy", "sale", "sales", "sell", "salenow", "promo", "resell", "buyers",
    "shop", "store", "coupon", "cute", "hot", "good", "love", "free", "deal", "dear",
    "help", "truth", "bank"
  ],
  brandBaitWords: ["bank", "card", "credit", "account", "login", "wallet"],
  trustedBrandDomains: [],
  freeMailDomains: [
    "gmail.com", "yahoo.com", "yahoo.co.jp", "hotmail.com", "outlook.com", "live.com",
    "icloud.com", "aol.com", "proton.me", "protonmail.com", "mail.com", "163.com",
    "126.com", "qq.com"
  ],
  ageNewDays: 30,
  ageYoungDays: 180,
  ageOneYearDays: 365
};
const GP_HISTORY_LIMIT = 100;

function GP_normalizeList(value) {
  if (Array.isArray(value)) {
    return value.map((item) => String(item).trim().toLowerCase()).filter(Boolean);
  }

  return String(value || "")
    .split(/[\n,]/)
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
}

function GP_normalizeDomain(value) {
  const text = String(value || "").trim().toLowerCase();
  if (!text) {
    return "";
  }

  try {
    return new URL(text.includes("://") ? text : `https://${text}`).hostname.replace(/\.$/, "");
  } catch {
    return text.split("/")[0].replace(/\.$/, "");
  }
}

function GP_normalizeDomainList(value) {
  return GP_normalizeList(value)
    .map(GP_normalizeDomain)
    .filter(Boolean);
}

function GP_normalizeUrl(value) {
  const text = String(value || "").trim();
  if (!text) {
    return "";
  }

  try {
    const url = new URL(text);
    url.hash = "";
    url.hostname = url.hostname.replace(/\.$/, "").toLowerCase();
    return url.href;
  } catch {
    return "";
  }
}

function GP_normalizeUrlList(value) {
  const entries = Array.isArray(value)
    ? value.map((item) => String(item).trim()).filter(Boolean)
    : String(value || "")
      .split(/[\n,]/)
      .map((item) => item.trim())
      .filter(Boolean);

  return entries
    .map(GP_normalizeUrl)
    .filter(Boolean);
}

function GP_isHostInDomainList(hostname, domains) {
  const host = GP_normalizeDomain(hostname);
  return domains.some((domain) => host === domain || host.endsWith(`.${domain}`));
}

function GP_isWhiteListedUrl(targetUrl, settings) {
  let url;
  try {
    url = new URL(targetUrl);
  } catch {
    return false;
  }

  const normalizedUrl = GP_normalizeUrl(url.href);
  return settings.whiteUrls.includes(normalizedUrl)
    || GP_isHostInDomainList(url.hostname, settings.whiteDomains);
}

function GP_getAlertListMatches(targetUrl, settings) {
  let url;
  try {
    url = new URL(targetUrl);
  } catch {
    return {
      url: false,
      domain: false,
      tld: ""
    };
  }

  const normalizedUrl = GP_normalizeUrl(url.href);
  const hostname = GP_normalizeDomain(url.hostname);
  const tld = hostname.split(".").at(-1) || "";

  return {
    url: settings.alertUrls.includes(normalizedUrl),
    domain: GP_isHostInDomainList(hostname, settings.alertDomains),
    tld: settings.alertTlds.includes(tld) ? tld : ""
  };
}

function GP_getFullscreenAllowMatchPatterns(settings) {
  return settings.fullscreenAllowUrls.flatMap((value) => {
    try {
      const url = new URL(value);
      if (!["http:", "https:"].includes(url.protocol)) {
        return [];
      }

      const path = url.pathname || "/";
      return [`${url.protocol}//${url.hostname}${path}*`];
    } catch {
      return [];
    }
  });
}

function GP_mergeSettings(value = {}) {
  const settings = { ...GP_DEFAULT_SETTINGS, ...value };
  for (const key of [
    "watchTlds",
    "commerceBaitWords",
    "brandBaitWords",
    "freeMailDomains"
  ]) {
    settings[key] = GP_normalizeList(settings[key]);
  }
  settings.whiteTlds = GP_normalizeList(settings.whiteTlds);
  settings.alertTlds = GP_normalizeList(settings.alertTlds);
  settings.whiteDomains = GP_normalizeDomainList(settings.whiteDomains);
  settings.alertDomains = GP_normalizeDomainList(settings.alertDomains);
  settings.trustedBrandDomains = GP_normalizeDomainList(settings.trustedBrandDomains);
  settings.whiteUrls = GP_normalizeUrlList(settings.whiteUrls);
  settings.alertUrls = GP_normalizeUrlList(settings.alertUrls);
  settings.fullscreenAllowUrls = GP_normalizeUrlList(settings.fullscreenAllowUrls);
  settings.ageNewDays = Number(settings.ageNewDays) || GP_DEFAULT_SETTINGS.ageNewDays;
  settings.ageYoungDays = Number(settings.ageYoungDays) || GP_DEFAULT_SETTINGS.ageYoungDays;
  settings.ageOneYearDays = Number(settings.ageOneYearDays) || GP_DEFAULT_SETTINGS.ageOneYearDays;
  settings.lowPatternUrlMinCount = Number(settings.lowPatternUrlMinCount) || GP_DEFAULT_SETTINGS.lowPatternUrlMinCount;
  return settings;
}

async function GP_getSettings() {
  const stored = await chrome.storage.local.get("gpSettings");
  return GP_mergeSettings(stored.gpSettings);
}

async function GP_saveSettings(settings) {
  await chrome.storage.local.set({ gpSettings: GP_mergeSettings(settings) });
}

async function GP_getHistory() {
  const stored = await chrome.storage.local.get("gpHistory");
  return Array.isArray(stored.gpHistory) ? stored.gpHistory : [];
}

async function GP_saveHistoryEntry(entry) {
  const history = await GP_getHistory();
  const nextHistory = [entry, ...history].slice(0, GP_HISTORY_LIMIT);
  await chrome.storage.local.set({ gpHistory: nextHistory });
  return nextHistory;
}

async function GP_clearHistory() {
  await chrome.storage.local.remove("gpHistory");
}
