# Site Checker

Site Checker is a Chrome and Microsoft Edge Manifest V3 extension for manually checking website signals and applying user-defined stopper rules.

It is a confirmation aid. It does not determine whether a website is safe, unsafe, legitimate, fraudulent, legal, or illegal.

## Overview

Site Checker helps users review a page before acting on it. The extension can show domain information, IP address candidates, RDAP registration data, external resource domains, email domains found on the page, and configurable confirmation signals.

The automatic stopper shows an in-page warning when the current page is outside the trusted list, or when it matches a user-configured must-check URL, must-check domain, or must-check TLD. Heuristic signals remain available in the popup for manual review.

## Main Features

- Manual page check from the browser toolbar popup.
- Current URL and registrable domain display.
- Google Public DNS over HTTPS lookup for `A` and `AAAA` records.
- RDAP lookup through `rdap.org`.
- Domain age display from RDAP registration events.
- External resource domain listing.
- Email domain extraction from the current page and selected same-site linked pages.
- Trusted URL, trusted domain, and trusted TLD settings.
- Must-check URL, must-check domain, and must-check TLD settings.
- Popup buttons for adding the current URL or domain to trusted and must-check lists.
- Popup button for opening the settings page.
- Automatic in-page warning and extension badge for pages outside the trusted list and must-check list matches.
- Page-driven fullscreen request blocking by default.
- Fullscreen allow URL path settings.
- Local scan history with JSON and CSV export.
- Settings import and export.
- In-page settings guide and field examples.

## Automatic Stopper

The automatic stopper uses explicit user-configured lists.

It displays a warning when the current page matches one of these:

- Outside trusted URL and trusted domain entries
- Must-check URL
- Must-check domain or its subdomain
- Must-check TLD

Trusted URL and trusted domain entries suppress automatic warnings.

Other signals, such as watched TLDs, low-pattern URL parts, Punycode, domain age, free-mail domains, and external resource domains, are shown in the popup for manual review. They are not used as automatic stopper triggers in the public-oriented configuration.

## Fullscreen Blocking

Site Checker blocks page-driven fullscreen requests by default. This is intended to reduce support-scam style pages that try to take over the screen.

Users can add fullscreen allow URL paths for pages where fullscreen behavior is expected. Allow entries are path-based because browser content-script matching does not support query-string-level exclusions.

Example:

```text
https://example.com/help
```

This allows fullscreen behavior for that path pattern.

## Installation

For local trial use, see [INSTALL.md](INSTALL.md).

Short version:

1. Download or extract the extension folder.
2. Open `chrome://extensions` or `edge://extensions`.
3. Enable developer mode.
4. Choose the unpacked extension loading option.
5. Select the folder containing `manifest.json`.

## Settings

Open the extension options page to configure:

- Trusted domains
- Trusted URLs
- Trusted TLDs
- Must-check domains
- Must-check URLs
- Must-check TLDs
- Fullscreen allow URL paths
- Watched TLDs
- Reference word lists
- Domain age thresholds
- Detail signal toggles

Settings are stored in `chrome.storage.local`.

The popup can add the current URL or registrable domain to the trusted and must-check lists. URL registration prompts allow editing before saving.

## History

Users can save selected scan results to local history. History entries may include:

- Checked URL
- Hostname
- Risk label and displayed signals
- IP address candidates
- RDAP domain age and registrar
- Email domains
- External resource domains

History is stored locally through `chrome.storage.local` and can be exported as JSON or CSV.

## Permissions

Site Checker uses the following extension permissions:

- `activeTab`: check the currently active page when the popup is opened.
- `scripting`: inspect page links, resource URLs, and email addresses, and register the fullscreen blocker.
- `tabs`: read the current tab URL and open the local history page.
- `storage`: save settings and scan history.

Host permissions:

- `http://*/*` and `https://*/*`: run the in-page must-check warning content script and fullscreen blocker on web pages.
- `https://dns.google/*`: query public DNS records.
- `https://rdap.org/*`: query RDAP domain data.

## Data And Network Use

Site Checker stores settings and saved history in the browser.

When the popup is opened, the extension may query:

- Google Public DNS over HTTPS for DNS records.
- `rdap.org` for domain registration data.

The extension does not include a developer-operated telemetry endpoint.

For details, see [PRIVACY.md](PRIVACY.md).

## Limitations

- DNS results may differ from the exact server used by the browser.
- RDAP data may be missing, delayed, or unavailable.
- CDN and proxy services can obscure infrastructure ownership.
- Page structure can prevent email or link extraction.
- The domain parser only has lightweight handling for common second-level TLDs such as `co.jp`, `co.uk`, and `com.cn`.
- Fullscreen blocking cannot prevent browser-level actions such as F11 or user-controlled window behavior.

## Important Notice

Site Checker is a review aid, not a security verdict engine.

False positives and false negatives are expected. Use official sources, URL inspection, certificate information, payment method checks, company information, and other verification methods before making important decisions.

See [DISCLAIMER.md](DISCLAIMER.md).

## Documents

- [INSTALL.md](INSTALL.md)
- [QUICK_START.md](QUICK_START.md)
- [README-TRIAL.md](README-TRIAL.md)
- [PRIVACY.md](PRIVACY.md)
- [DISCLAIMER.md](DISCLAIMER.md)
- [PUBLIC_RELEASE.md](PUBLIC_RELEASE.md)
- [DISTRIBUTION.md](DISTRIBUTION.md)
- [CHANGELOG.md](CHANGELOG.md)
