importScripts("settings.js");
const FULLSCREEN_BLOCKER_SCRIPT_ID = "gp-fullscreen-blocker";

async function registerFullscreenBlocker() {
  const settings = await GP_getSettings();
  const excludeMatches = GP_getFullscreenAllowMatchPatterns(settings);

  await chrome.scripting.unregisterContentScripts({
    ids: [FULLSCREEN_BLOCKER_SCRIPT_ID]
  }).catch(() => {});

  const blockerScript = {
    id: FULLSCREEN_BLOCKER_SCRIPT_ID,
    matches: ["http://*/*", "https://*/*"],
    js: ["fullscreen-blocker.js"],
    runAt: "document_start",
    allFrames: true,
    world: "MAIN",
    persistAcrossSessions: true
  };
  if (excludeMatches.length) {
    blockerScript.excludeMatches = excludeMatches;
  }

  await chrome.scripting.registerContentScripts([blockerScript]);
}

function isIpAddress(hostname) {
  return /^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname) || hostname.includes(":");
}

function getRegistrableDomain(hostname) {
  const cleanHost = hostname.replace(/\.$/, "").toLowerCase();
  if (isIpAddress(cleanHost) || cleanHost === "localhost") {
    return cleanHost;
  }

  const parts = cleanHost.split(".").filter(Boolean);
  if (parts.length <= 2) {
    return cleanHost;
  }

  const secondLevelTlds = new Set([
    "ac.jp", "ad.jp", "co.jp", "ed.jp", "go.jp", "gr.jp", "lg.jp", "ne.jp", "or.jp",
    "co.uk", "org.uk", "ac.uk", "gov.uk",
    "com.au", "net.au", "org.au",
    "com.cn", "net.cn", "org.cn", "gov.cn",
    "com.tw", "net.tw", "org.tw",
    "com.hk", "net.hk", "org.hk",
    "co.kr", "or.kr", "go.kr"
  ]);
  const lastTwo = parts.slice(-2).join(".");

  if (secondLevelTlds.has(lastTwo) && parts.length >= 3) {
    return parts.slice(-3).join(".");
  }

  return parts.slice(-2).join(".");
}

function assessDomainRisk(url, settings) {
  const items = [];
  const parsed = new URL(url);
  const hostname = parsed.hostname;
  const cleanHost = hostname.replace(/\.$/, "").toLowerCase();

  if (GP_isWhiteListedUrl(parsed.href, settings)) {
    return { level: "low", score: 0, items: [] };
  }

  const alertMatches = GP_getAlertListMatches(parsed.href, settings);
  if (alertMatches.url) {
    items.push("要確認URL");
  }
  if (alertMatches.domain) {
    items.push("要確認ドメイン");
  }
  if (alertMatches.tld) {
    items.push(`要確認TLD .${alertMatches.tld}`);
  }
  if (settings.autoWarnUntrustedDomain && !GP_isHostInDomainList(cleanHost, settings.whiteDomains)) {
    items.push("信頼リスト外");
  }

  const score = items.length ? 5 : 0;
  const level = items.length ? "high" : "low";
  return { level, score, items };
}

async function clearTabWarning(tabId) {
  await chrome.action.setBadgeText({ tabId, text: "" });
}

async function sendTabWarning(tabId, message) {
  const send = () => chrome.tabs.sendMessage(tabId, message);

  try {
    await send();
    return;
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["auto-warning.js"]
    });
    await send().catch(() => {});
  }
}

async function applyTabWarning(tabId, url) {
  const settings = await GP_getSettings();
  if (!settings.autoWarningEnabled) {
    await clearTabWarning(tabId);
    return;
  }

  const parsed = new URL(url);
  if (!["http:", "https:"].includes(parsed.protocol)) {
    await clearTabWarning(tabId);
    return;
  }

  const assessment = assessDomainRisk(url, settings);
  if (assessment.level === "low") {
    await clearTabWarning(tabId);
    return;
  }

  const isHigh = assessment.level === "high";
  await chrome.action.setBadgeText({ tabId, text: isHigh ? "!" : "?" });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: isHigh ? "#dc2626" : "#f97316" });

  await sendTabWarning(tabId, {
    type: "current-page-inspector:risk-warning",
    level: assessment.level,
    hostname: parsed.hostname,
    items: assessment.items
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url) {
    return;
  }

  applyTabWarning(tabId, tab.url).catch(() => {});
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab?.url) {
    applyTabWarning(tabId, tab.url).catch(() => {});
  }
});

chrome.runtime.onInstalled.addListener(() => {
  registerFullscreenBlocker().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  registerFullscreenBlocker().catch(() => {});
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.gpSettings) {
    registerFullscreenBlocker().catch(() => {});
    chrome.tabs.query({}).then((tabs) => {
      for (const tab of tabs) {
        if (tab.id && tab.url) {
          applyTabWarning(tab.id, tab.url).catch(() => {});
        }
      }
    }).catch(() => {});
  }
});

registerFullscreenBlocker().catch(() => {});
