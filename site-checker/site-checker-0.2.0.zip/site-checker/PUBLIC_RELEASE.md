# Site Checker 公開最小パッケージ

この文書は、Site Checker を最小構成で公開・共有するためのまとめです。

## 公開するもの

公開初期版では、以下をひとまとめにしたzipを配布します。

`site-checker-0.2.0-local.zip`

zipの中には、拡張機能本体と利用者向け文書を含めます。

- `manifest.json`
- `icons/`
- `auto-warning.js`
- `background.js`
- `fullscreen-blocker.js`
- `popup.html`, `popup.css`, `popup.js`
- `options.html`, `options.css`, `options.js`
- `history.html`, `history.css`, `history.js`
- `settings.js`
- `README.md`
- `README-TRIAL.md`
- `INSTALL.md`
- `QUICK_START.md`
- `PRIVACY.md`
- `DISCLAIMER.md`
- `CHANGELOG.md`
- `PUBLIC_RELEASE.md`

## 公開初期版の位置づけ

Site Checker は、Webサイト確認を補助するローカル利用向けブラウザ拡張機能です。

安全・危険・詐欺・正規などを断定するものではありません。表示された情報は、利用者が確認するための材料として扱います。

## 最小機能

- 現在ページのURLとドメイン確認
- IP候補の確認
- RDAP情報とドメイン年齢の確認
- 外部リソースドメインの一覧化
- ページ内メールドメインの確認
- 信頼リスト
- 要確認リスト
- 要確認TLD
- 自動警告バー
- 全画面ブロック
- 全画面許可URLパス
- 判定履歴の保存と書き出し
- 設定のインポート/エクスポート
- 設定画面のガイド

## 初期公開で避けるもの

- 特定サイトや特定事業者を詐欺と断定する表現
- 特定TLDや国を一律に危険扱いする表現
- ランダム寄りドメイン判定だけで自動警告する設定
- IP国判定など精度が不安定な機能
- 開発者側の独自テレメトリー

## 利用者への案内

利用者には、まず以下を読んでもらいます。

- `INSTALL.md`
- `QUICK_START.md`
- `PRIVACY.md`
- `DISCLAIMER.md`

特に、以下を明確に伝えます。

- この拡張機能は判定補助であり、安全/危険を断定しない
- DNS確認では Google Public DNS over HTTPS を使用する
- RDAP確認では `rdap.org` を使用する
- 設定と履歴はブラウザ内に保存される
- 展開したフォルダは削除・移動しない
- 必要な設定や履歴は利用者自身で書き出して管理する

## 配布前チェック

配布前に以下を確認します。

1. `manifest.json` が正しいJSONとして読める
2. 主要JavaScriptファイルの構文チェックが通る
3. ChromeまたはEdgeでローカル読み込みできる
4. ポップアップが開く
5. 設定画面が開く
6. 履歴画面が開く
7. 全画面ブロックが動く
8. 要確認リストに一致したページで警告バーが出る

## 公開後の更新

新しい版を配布する場合は、zipを差し替えます。

利用者は展開済みフォルダを新しいものに置き換え、ブラウザの拡張機能ページで「更新」を押します。
