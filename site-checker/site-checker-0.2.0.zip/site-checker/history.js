const historyList = document.querySelector("#historyList");
const statusText = document.querySelector("#status");
const exportJsonButton = document.querySelector("#exportJsonButton");
const exportCsvButton = document.querySelector("#exportCsvButton");
const clearButton = document.querySelector("#clearButton");
let historyRows = [];

function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value || "";
  }

  return date.toLocaleString("ja-JP", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function badgeClass(row) {
  if (row.riskLabel === "強め") {
    return "badge is-high";
  }
  if (row.riskLabel === "要確認") {
    return "badge is-medium";
  }
  return "badge";
}

function joinValues(values) {
  return Array.isArray(values) && values.length ? values.join(", ") : "なし";
}

function renderHistory(rows) {
  historyList.replaceChildren();
  statusText.textContent = rows.length ? `${rows.length}件の履歴` : "履歴はありません。";

  if (!rows.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "保存された判定履歴はありません。";
    historyList.append(empty);
    return;
  }

  for (const row of rows) {
    const card = document.createElement("article");
    const head = document.createElement("div");
    const titleWrap = document.createElement("div");
    const url = document.createElement("p");
    const meta = document.createElement("p");
    const badge = document.createElement("span");
    const details = document.createElement("div");

    card.className = "history-card";
    head.className = "history-head";
    url.className = "url";
    meta.className = "meta";
    badge.className = badgeClass(row);
    details.className = "details";

    url.textContent = row.url;
    meta.textContent = `${formatDateTime(row.checkedAt)} / ${row.hostname || ""}`;
    badge.textContent = row.riskLabel || "低め";

    const detailRows = [
      ["シグナル", joinValues(row.signals)],
      ["メール", joinValues(row.mailDomains)],
      ["外部リソース", joinValues(row.externalDomains)],
      ["IP", joinValues(row.ipAddresses)],
      ["ドメイン年齢", Number.isInteger(row.domainAgeDays) ? `${row.domainAgeDays}日` : "不明"],
      ["Registrar", row.registrar || "不明"]
    ];

    for (const [label, value] of detailRows) {
      const item = document.createElement("div");
      const term = document.createElement("span");
      const description = document.createElement("strong");
      term.textContent = label;
      description.textContent = value;
      item.append(term, description);
      details.append(item);
    }

    titleWrap.append(url, meta);
    head.append(titleWrap, badge);
    card.append(head, details);
    historyList.append(card);
  }
}

function downloadText(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function toCsvValue(value) {
  const text = Array.isArray(value) ? value.join(" | ") : String(value ?? "");
  return `"${text.replace(/"/g, '""')}"`;
}

function exportCsv(rows) {
  const columns = [
    "checkedAt", "url", "hostname", "registrableDomain", "riskLabel", "riskScore",
    "signals", "domainAgeDays", "registrar", "mailDomains", "externalDomains", "ipAddresses"
  ];
  const lines = [
    columns.join(","),
    ...rows.map((row) => columns.map((column) => toCsvValue(row[column])).join(","))
  ];
  downloadText(`gp-site-checker-history-${new Date().toISOString().slice(0, 10)}.csv`, lines.join("\n"), "text/csv");
}

async function loadHistory() {
  historyRows = await GP_getHistory();
  renderHistory(historyRows);
}

exportJsonButton.addEventListener("click", () => {
  downloadText(
    `gp-site-checker-history-${new Date().toISOString().slice(0, 10)}.json`,
    JSON.stringify({ gpHistory: historyRows }, null, 2),
    "application/json"
  );
});

exportCsvButton.addEventListener("click", () => exportCsv(historyRows));

clearButton.addEventListener("click", async () => {
  if (!confirm("判定履歴をすべて削除しますか？")) {
    return;
  }

  await GP_clearHistory();
  await loadHistory();
});

loadHistory();
