(() => {
  const blockedFullscreenError = () => {
    const error = new DOMException("Fullscreen requests are blocked by Site Checker.", "NotAllowedError");
    window.dispatchEvent(new CustomEvent("current-page-inspector:fullscreen-blocked"));
    return Promise.reject(error);
  };

  const blockMethod = (prototype, methodName, replacement) => {
    if (!prototype || typeof prototype[methodName] !== "function") {
      return;
    }

    try {
      Object.defineProperty(prototype, methodName, {
        configurable: true,
        writable: true,
        value: replacement
      });
    } catch {
      prototype[methodName] = replacement;
    }
  };

  blockMethod(Element.prototype, "requestFullscreen", blockedFullscreenError);
  blockMethod(Element.prototype, "webkitRequestFullscreen", blockedFullscreenError);
  blockMethod(Element.prototype, "mozRequestFullScreen", blockedFullscreenError);
  blockMethod(Element.prototype, "msRequestFullscreen", blockedFullscreenError);

  blockMethod(window, "resizeTo", () => undefined);
  blockMethod(window, "resizeBy", () => undefined);
  blockMethod(window, "moveTo", () => undefined);
  blockMethod(window, "moveBy", () => undefined);
})();
