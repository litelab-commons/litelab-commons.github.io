if (!globalThis.GP_autoWarningListenerReady) {
  globalThis.GP_autoWarningListenerReady = true;

  const renderWarning = (message) => {
  if (message?.type !== "current-page-inspector:risk-warning") {
    return;
  }

  const existing = document.querySelector("[data-current-page-inspector-warning]");
  if (existing) {
    existing.remove();
  }

  const banner = document.createElement("div");
  banner.dataset.currentPageInspectorWarning = "true";
  banner.style.position = "fixed";
  banner.style.top = "12px";
  banner.style.left = "50%";
  banner.style.transform = "translateX(-50%)";
  banner.style.zIndex = "2147483647";
  banner.style.boxSizing = "border-box";
  banner.style.width = "min(560px, calc(100vw - 24px))";
  banner.style.padding = "14px 16px";
  banner.style.border = message.level === "high" ? "3px solid #dc2626" : "3px solid #f97316";
  banner.style.borderRadius = "8px";
  banner.style.background = message.level === "high" ? "#fef2f2" : "#fff7ed";
  banner.style.color = "#111827";
  banner.style.font = "13px/1.45 system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
  banner.style.boxShadow = message.level === "high"
    ? "0 0 0 5px rgba(220, 38, 38, 0.22), 0 18px 50px rgba(15, 23, 42, 0.34)"
    : "0 0 0 4px rgba(249, 115, 22, 0.2), 0 18px 50px rgba(15, 23, 42, 0.28)";

  const title = document.createElement("strong");
  title.textContent = "⚠ 確認すべき項目があります。詳細を確認しましょう。";
  title.style.display = "block";
  title.style.marginBottom = "4px";
  title.style.fontSize = "18px";
  title.style.lineHeight = "1.25";
  title.style.color = message.level === "high" ? "#991b1b" : "#9a3412";

  const detail = document.createElement("div");
  detail.textContent = `${message.hostname}: ${message.items.slice(0, 3).join(" / ")}`;
  detail.style.display = "none";
  detail.style.marginTop = "6px";

  const actions = document.createElement("div");
  actions.style.display = "flex";
  actions.style.gap = "8px";
  actions.style.marginTop = "8px";

  const details = document.createElement("button");
  details.type = "button";
  details.textContent = "詳細を見る";
  details.style.border = "0";
  details.style.borderRadius = "6px";
  details.style.padding = "6px 10px";
  details.style.background = message.level === "high" ? "#dc2626" : "#f97316";
  details.style.color = "#ffffff";
  details.style.cursor = "pointer";
  details.style.font = "700 12px/1 system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
  details.addEventListener("click", () => {
    const isOpen = detail.style.display !== "none";
    detail.style.display = isOpen ? "none" : "block";
    details.textContent = isOpen ? "詳細を見る" : "詳細を隠す";
  });

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "閉じる";
  close.style.border = "0";
  close.style.borderRadius = "6px";
  close.style.padding = "6px 10px";
  close.style.background = "#111827";
  close.style.color = "#ffffff";
  close.style.cursor = "pointer";
  close.style.font = "700 12px/1 system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
  close.addEventListener("click", () => banner.remove());

  actions.append(details, close);
  banner.append(title, detail, actions);
  const mount = document.documentElement || document.body;
  if (mount) {
    mount.append(banner);
  }
};

chrome.runtime.onMessage.addListener((message) => {
  renderWarning(message);
});
}
