# Changelog

## 0.2.0

- Renamed user-facing whitelist wording to trusted list wording.
- Added must-check domains, URLs, and TLDs.
- Clarified watched TLDs as a separate, lower-strength signal from must-check TLDs.
- Reorganized the settings page into trusted list, must-check list, TLD list, and reference list sections.
- Scoped automatic stopper warnings to must-check URL, domain, and TLD list matches.
- Added fullscreen allow URL paths while keeping fullscreen blocking enabled by default.
- Added popup actions for adding the current URL or domain to must-check lists.
- Added a popup action for opening the settings page.
- Added settings page help text for trusted lists, must-check lists, TLD lists, and reference lists.
- Added an in-page settings guide and field-level examples.
- Removed stale automatic heuristic warning flags from the public-oriented release path.
- Updated trial distribution documents and privacy/disclaimer notes.
- Prepared the local public release package.

## 0.1.0

- Added the initial Site Checker browser extension.
- Added page IP candidate lookup through Google Public DNS over HTTPS.
- Added RDAP lookup and domain age display.
- Added external resource domain and email domain extraction.
- Added configurable site-check signals.
- Added trusted domain and trusted URL suppression.
- Added local scan history and settings import/export.
- Added extension icons and trial distribution documents.
