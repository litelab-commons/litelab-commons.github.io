const form = document.querySelector("#settingsForm");
const statusText = document.querySelector("#status");
const resetButton = document.querySelector("#resetButton");
const exportButton = document.querySelector("#exportButton");
const importButton = document.querySelector("#importButton");
const importFile = document.querySelector("#importFile");

const listFields = [
  "whiteDomains",
  "whiteUrls",
  "fullscreenAllowUrls",
  "whiteTlds",
  "alertDomains",
  "alertUrls",
  "alertTlds",
  "watchTlds",
  "commerceBaitWords",
  "brandBaitWords",
  "trustedBrandDomains",
  "freeMailDomains"
];
const booleanFields = [
  "autoWarningEnabled",
  "autoWarnUntrustedDomain",
  "detailBrandSignal",
  "detailDomainAgeSignal",
  "detailMailSignal",
  "detailLowPatternUrlSignal"
];
const numberFields = ["ageNewDays", "ageYoungDays", "ageOneYearDays", "lowPatternUrlMinCount"];

function renderSettings(settings) {
  for (const field of listFields) {
    document.querySelector(`#${field}`).value = settings[field].join("\n");
  }
  for (const field of booleanFields) {
    document.querySelector(`#${field}`).checked = Boolean(settings[field]);
  }
  for (const field of numberFields) {
    document.querySelector(`#${field}`).value = settings[field];
  }
}

function readSettings() {
  const settings = {};
  for (const field of listFields) {
    settings[field] = GP_normalizeList(document.querySelector(`#${field}`).value);
  }
  for (const field of booleanFields) {
    settings[field] = document.querySelector(`#${field}`).checked;
  }
  for (const field of numberFields) {
    settings[field] = Number(document.querySelector(`#${field}`).value);
  }
  return GP_mergeSettings(settings);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  await GP_saveSettings(readSettings());
  statusText.textContent = "保存しました。";
});

resetButton.addEventListener("click", async () => {
  await chrome.storage.local.remove("gpSettings");
  renderSettings(GP_mergeSettings());
  statusText.textContent = "初期値に戻しました。";
});

exportButton.addEventListener("click", async () => {
  const settings = await GP_getSettings();
  const blob = new Blob([JSON.stringify({ gpSettings: settings }, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `gp-site-checker-settings-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
  statusText.textContent = "設定を書き出しました。";
});

importButton.addEventListener("click", () => {
  importFile.value = "";
  importFile.click();
});

importFile.addEventListener("change", async () => {
  const file = importFile.files?.[0];
  if (!file) {
    return;
  }

  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const settings = GP_mergeSettings(data.gpSettings || data);
    await GP_saveSettings(settings);
    renderSettings(settings);
    statusText.textContent = "設定を読み込みました。";
  } catch (error) {
    statusText.textContent = "設定ファイルを読み込めませんでした。";
    console.error(error);
  }
});

GP_getSettings().then(renderSettings);
